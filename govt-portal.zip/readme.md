# Rabies Response — Design System

Shared visual language for **Rabies Response**, a public-health platform for Jabalpur, Madhya Pradesh. Three products:
1. **Citizen app** (Flutter, Android-first): report animal bites, get first aid, find hospitals, track vaccine doses.
2. **Government portal** (React + Tailwind): health officials monitor cases, manage hospitals, publish notices.
3. **Hospital portal** (React + Tailwind): staff accept bite reports and record anti-rabies vaccine doses.

**Sources:** a written brief and 4 mood-reference images (`uploads/pasted-*.png`): warm cream phone UIs, deep teal and amber, soft sage, very rounded cards. We kept their palette and roundness. We dropped their illustrations, gradients and big shadows because of the performance rules. No codebase, Figma file or logo was provided. **There is no logo.** `LogoSlot` is a dashed placeholder for the department's logo. Never use a real government emblem.

## Index
- `styles.css`: the one file consumers link (imports only)
- `tokens/`: colors.css (light + `[data-theme="dark"]`), typography.css (mobile default + `[data-density="desktop"]`), spacing.css (spacing, radii, borders, shadow, motion, control sizes), base.css
- `tokens/tokens.json`: platform-neutral source, including the shared `status` map
- `tokens/tailwind.preset.js`: Tailwind 3 preset (colours point to CSS vars; blur, gradient and drop-shadow utilities disabled)
- `tokens/flutter/rr_theme.dart`: Material 3 `ThemeData` + `ColorScheme` + `RRColors` ThemeExtension + `RRStatus` map
- `components/`: core (Icon, LogoSlot, SegmentedToggle), actions (Button), forms (Field, TextField, SelectField, DateField, TextArea), status (StatusBadge, StatTile, statusMap.js), surfaces (Card, List/ListItem, DataTable), overlays (Dialog, SidePanel, Toast/ToastRegion), feedback (EmptyState, ErrorState, Skeleton, OfflineBanner). Styles are in `components/components.css`.
- `guidelines/`: foundation specimen cards
- `ui_kits/citizen-app/`: click-through recreation at 360 and 320 px
- `ui_kits/gov-portal/`: dashboard, bite reports (table + side panel, list/map), hospitals. Its `PortalShell.jsx` is shared.
- `ui_kits/hospital-portal/`: incoming report queue, vaccine dose tracker
- `assets/icons/`: 50 Lucide outline SVGs (ISC licence). `assets/ds-dev-loader.js` is a preview helper that compiles components in the browser when the bundle is missing.
- **Intentional additions:** SegmentedToggle (List/Map switch), Field (shared label/error wrapper), LogoSlot.

## Content fundamentals
- **Plain words for low-literacy readers.** Use short sentences and everyday verbs. Talk to the user as "you" ("Report it now", "Your number is RR-0142"). Never use "I" or "we" for the system, except for promises like "We will send an SMS".
- **Sentence case** everywhere. Never use ALL CAPS for meaning.
- Put the action first and the reason second: "Wash the wound for 15 minutes." Use numbers as digits.
- Buttons use verb + object: "Send report", "Accept patient", "Call 108 ambulance". Loading labels use -ing words: "Sending…", "भेज रहे हैं…".
- Errors explain how to fix the problem, not what went wrong: "Enter all 10 digits". Put a network error on screen with a Retry button.
- Say "Don't" plainly for dangerous folk remedies: "Do not put chilli, oil, turmeric or lime on it."
- Bilingual: every string exists in English and Hindi. Hindi runs about 30% longer, so text wraps and never truncates. Use natural spoken Hindi, not Sanskritised Hindi (शिकायत rather than प्रतिवेदन).
- No emoji. No exclamation marks. Tone is calm and official, never alarmist, even for outbreaks.

## Visual foundations
- **Colour:** warm cream background (#F7F3EC), white surfaces, deep teal primary (#1E4D5A), sage secondary. **Emergency red (#C0271D) is used only for bite reporting and SOS.** Danger is the colour for destructive actions and errors. Semantic tones come as base + container + on-container + border. Dark theme uses the same names with a teal-grey ink. All text pairs are AA or better. The high-ink text works in sunlight.
- **Status mapping** (identical everywhere, from `statusMap.js` / `tokens.json`):
  - **Case:** Reported = warning, Accepted = info, Under Treatment = primary, Completed = success, Cancelled = neutral.
  - **Severity:** Minor Scratch = neutral, Bleeding Wound = warning, Deep Wound = orange, Multiple Bites = solid emergency red. Each also shows 1–4 level pips.
  - **Hospital:** Active = success, Inactive = neutral.
  - **Notice:** Outbreak Alert = danger, General Awareness = info, New Hospital = success, Maintenance Notice = warning.
  - Every badge has an icon and text, so colour is never the only signal.
- **Type:** system stack only: Roboto / Segoe UI, with Noto Sans Devanagari / Nirmala UI / Mangal for Hindi. There is no webfont download. Two weights, 400 and 600. Mobile body text is 16 px, desktop 14 px. Line-heights are at least 1.4 so Devanagari matras don't clip. Use mono only for report IDs.
- **Spacing:** 4 px base (4, 8, 12, 16, 20, 24, 32, 40, 48, 64). Mobile screens use 16 px padding and 16 px gaps between cards.
- **Radii:** soft and generous, following the references. Inputs 12, cards and dialogs 16, sheets 24, buttons and badges are pill-shaped.
- **Borders and elevation:** flat surfaces with 1 px borders. Input borders use `border-strong` (3:1). Error state uses a 2 px border. Focus is a 3 px outline. There is **one** shadow (`--shadow-1`), used only on floating items (toast, dialog, raised card).
- **Backgrounds:** solid colours only. No images, gradients, textures, blur or transparency. The one exception is the flat scrim behind modals.
- **Imagery:** none. Empty and error states use a single icon in a circle.
- **Motion:** colour and opacity only, 120–150 ms, `cubic-bezier(0.2,0,0,1)`. Nothing slides, spins or shimmers. Loaders are static glyphs and skeletons are static blocks. `prefers-reduced-motion` sets durations to 0.
- **States:**
  - Hover darkens the fill (primary → primary-hover) or tints it with primary-container (secondary, text, rows).
  - Pressed goes one step darker. There is no shrink or ripple (Flutter uses `NoSplash`).
  - Disabled uses a flat grey fill.
  - Focus is always visible.
- **Cards:** white, 1 px border, 16 radius, no shadow. The "tinted" variant uses a cream fill with no border. The "brand" variant uses a teal fill, at most one per screen (e.g. next dose). Never use a coloured left-border accent.
- **Layout:**
  - Mobile is a single column that works at 320 px. The bottom nav always shows labels.
  - Portals target 1366 and 1024 px, with a 240 px sidebar, tables that scroll horizontally, and a 480 px side panel.
  - Every map sits behind a List / Map toggle. The list is the default, and the map loads only on tap.
- **Sizing:** touch targets are at least 48 dp. Controls are 48 px (mobile) and 40 px (desktop). The hero CTA is 56 px. Buttons size to their content so Hindi fits.

## Iconography
[Lucide](https://lucide.dev) outline set (stroke 2, 24 grid). 50 icons are copied into `assets/icons/` and inlined in `components/core/iconData.js`, so they need no network request. Sizes: 16 in badges, 20 in buttons and fields, 22–24 in navigation. Icons always sit next to a text label on critical actions. An icon-only button (close ×) must have an `aria-label`. No emoji, no unicode glyph icons, no icon font. In Flutter, use `lucide_icons_flutter` or the outlined Material equivalents listed in `rr_theme.dart`.
