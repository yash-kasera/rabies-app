Basic surface container. Never add a coloured left border; use a StatusBadge inside instead.

```jsx
<Card><h3>Nearest hospital</h3>…</Card>
<Card variant="brand">Next dose: Day 7 · 12 Oct</Card>
<Card onClick={open}>Tap-able report summary</Card>
```
