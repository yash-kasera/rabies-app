import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function ListItem({ icon, title, subtitle, meta, trailing, chevron, onClick, href }) {
  const Tag = href ? 'a' : onClick ? 'button' : 'div';
  return (
    <Tag className="rr-li" onClick={onClick} href={href} type={Tag === 'button' ? 'button' : undefined}>
      {icon && <span className="rr-li__lead"><Icon name={icon} /></span>}
      <span className="rr-li__body">
        <span className="rr-li__title">{title}</span>
        {subtitle && <span className="rr-li__sub">{subtitle}</span>}
        {meta && <span className="rr-li__sub">{meta}</span>}
      </span>
      {(trailing || chevron) && <span className="rr-li__trail">{trailing}{chevron && <Icon name="chevron-right" />}</span>}
    </Tag>
  );
}

export function List({ children, label }) {
  return <ul className="rr-list" aria-label={label}>{React.Children.map(children, c => c ? <li>{c}</li> : null)}</ul>;
}
