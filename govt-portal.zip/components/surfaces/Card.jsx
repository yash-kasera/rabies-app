import React from 'react';
const cx = (...a) => a.filter(Boolean).join(' ');

export function Card({ variant = 'default', padding = 'md', raised, onClick, className, children, ...rest }) {
  const Tag = onClick ? 'button' : 'div';
  return (
    <Tag className={cx('rr-card', variant !== 'default' && 'rr-card--' + variant, padding !== 'md' && 'rr-card--pad-' + padding, raised && 'rr-card--raised', onClick && 'rr-card--interactive', className)}
      onClick={onClick} type={onClick ? 'button' : undefined} {...rest}>{children}</Tag>
  );
}
