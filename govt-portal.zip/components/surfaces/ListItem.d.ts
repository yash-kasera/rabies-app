import { IconName } from '../core/Icon';
/** Row for lists (hospitals, reports, notices). Min 64px tall; the whole row is the touch target. Wrap rows in <List>. */
export interface ListItemProps {
  icon?: IconName;
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  meta?: React.ReactNode;
  /** Right side content — usually a StatusBadge or distance */
  trailing?: React.ReactNode;
  chevron?: boolean;
  onClick?: () => void;
  href?: string;
}
export declare function ListItem(props: ListItemProps): JSX.Element;
export declare function List(props: { children?: React.ReactNode; label?: string }): JSX.Element;
