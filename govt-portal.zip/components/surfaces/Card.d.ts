/** Flat container: white surface, 1px border, 16px radius. */
export interface CardProps extends React.HTMLAttributes<HTMLElement> {
  /** default = white + border; tinted = cream surface-alt, no border; brand = deep teal (one per screen, e.g. next-dose summary) */
  variant?: 'default' | 'tinted' | 'brand';
  padding?: 'none' | 'md' | 'lg';
  /** The single allowed shadow level. Use for floating items only. */
  raised?: boolean;
  /** Makes the whole card a button with hover/pressed/focus states */
  onClick?: () => void;
  children?: React.ReactNode;
}
export declare function Card(props: CardProps): JSX.Element;
