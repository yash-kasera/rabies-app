import React from 'react';

export function DataTable({ columns, rows, caption, loading, skeletonRows = 5, empty, rowKey = 'id', onRowClick, selectedKey }) {
  return (
    <div className="rr-table-wrap">
      <table className="rr-table" aria-busy={loading ? 'true' : undefined}>
        {caption && <caption>{caption}</caption>}
        <thead><tr>{columns.map(c => <th key={c.key} scope="col" className={c.align === 'right' ? 'is-num' : undefined} style={c.width ? { width: c.width } : undefined}>{c.label}</th>)}</tr></thead>
        <tbody>
          {loading ? Array.from({ length: skeletonRows }).map((_, i) => (
            <tr key={'s' + i}>{columns.map((c, j) => <td key={c.key}><span className="rr-skel rr-skel--text" style={{ width: (40 + ((i * 7 + j * 13) % 45)) + '%' }} /></td>)}</tr>
          )) : rows.length === 0 && empty ? (
            <tr><td colSpan={columns.length}>{empty}</td></tr>
          ) : rows.map(r => (
            <tr key={r[rowKey]} className={(onRowClick ? 'is-clickable' : '') + (selectedKey === r[rowKey] ? ' is-selected' : '')}
              onClick={onRowClick ? () => onRowClick(r) : undefined} tabIndex={onRowClick ? 0 : undefined}
              onKeyDown={onRowClick ? e => { if (e.key === 'Enter') onRowClick(r); } : undefined}>
              {columns.map(c => <td key={c.key} className={c.align === 'right' ? 'is-num' : undefined}>{c.render ? c.render(r) : r[c.key]}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
