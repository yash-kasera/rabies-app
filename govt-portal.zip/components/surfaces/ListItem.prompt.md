List row, the default way to show hospitals and reports (map is an optional toggle).

```jsx
<List label="Nearby hospitals">
  <ListItem icon="hospital" title="Victoria District Hospital" subtitle="2.1 km · Open 24 hours" trailing={<StatusBadge kind="hospital" value="active" />} chevron onClick={…} />
</List>
```
