/**
 * Desktop data table: sticky cream header, 1px row dividers, clickable rows, skeleton + empty states. Scrolls horizontally at 1024px.
 * @startingPoint section="Data" subtitle="Case table with status badges" viewport="700x420"
 */
export interface DataTableColumn<R = any> {
  key: string;
  label: string;
  align?: 'left' | 'right';
  width?: string | number;
  render?: (row: R) => React.ReactNode;
}
export interface DataTableProps<R = any> {
  columns: DataTableColumn<R>[];
  rows: R[];
  caption?: string;
  loading?: boolean;
  skeletonRows?: number;
  /** Rendered inside a full-width cell when rows is empty — pass an <EmptyState> */
  empty?: React.ReactNode;
  rowKey?: string;
  onRowClick?: (row: R) => void;
  selectedKey?: string;
}
export declare function DataTable(props: DataTableProps): JSX.Element;
