Portal table for cases, hospitals, doses. Pair row clicks with a SidePanel for details.

```jsx
<DataTable columns={[{ key: 'id', label: 'Report ID', render: r => <span className="rr-mono">{r.id}</span> }, { key: 'status', label: 'Status', render: r => <StatusBadge kind="case" value={r.status} /> }]}
  rows={cases} onRowClick={setSelected} empty={<EmptyState title="No reports yet" />} />
```
