/** Static placeholder blocks (no shimmer — nothing animates continuously). Parent should set aria-busy. */
export interface SkeletonProps {
  variant?: 'block' | 'text' | 'circle' | 'list-item';
  width?: number | string;
  height?: number | string;
  /** text variant only */
  lines?: number;
  radius?: number | string;
}
export declare function Skeleton(props: SkeletonProps): JSX.Element;
