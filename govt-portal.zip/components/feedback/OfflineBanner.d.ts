/** Full-width strip under the app bar when the network drops. Stays until connectivity returns; then shows a green "back online" line for 4s. */
export interface OfflineBannerProps {
  online?: boolean;
  title?: string;
  message?: string;
  /** e.g. "Last updated 10:42" */
  lastSync?: string;
  onRetry?: () => void;
  retryLabel?: string;
  backOnlineLabel?: string;
}
export declare function OfflineBanner(props: OfflineBannerProps): JSX.Element;
