Static loading placeholders shaped like the content that is coming.

```jsx
<Skeleton variant="list-item" />
<Skeleton variant="text" lines={3} />
<Skeleton height={120} radius={16} />
```
