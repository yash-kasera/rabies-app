import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function OfflineBanner({ online, title = 'You are offline.', message = 'Showing saved information. Reports will send when you are back online.', lastSync, onRetry, retryLabel = 'Retry', backOnlineLabel = 'Back online. Saved reports sent.' }) {
  if (online) return <div className="rr-offline rr-offline--online" role="status"><Icon name="circle-check" size={18} /><span className="rr-offline__msg"><strong>{backOnlineLabel}</strong></span></div>;
  return (
    <div className="rr-offline" role="status">
      <Icon name="wifi-off" size={18} />
      <span className="rr-offline__msg"><strong>{title}</strong> {message}{lastSync ? ' ' + lastSync : ''}</span>
      {onRetry && <button type="button" className="rr-offline__btn" onClick={onRetry}><Icon name="refresh-cw" size={16} />{retryLabel}</button>}
    </div>
  );
}
