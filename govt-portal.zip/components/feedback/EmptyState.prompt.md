Empty list placeholder; say what is empty and what to do next.

```jsx
<EmptyState icon="file-text" title="No reports yet" body="If an animal bites you or your family, report it here." action={<Button variant="emergency" icon="siren">Report a bite</Button>} />
```
