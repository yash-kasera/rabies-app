import React from 'react';

export function Skeleton({ variant = 'block', width = '100%', height, lines = 3, radius }) {
  if (variant === 'text') {
    return <span className="rr-skel-stack" aria-hidden="true">{Array.from({ length: lines }).map((_, i) => <span key={i} className="rr-skel rr-skel--text" style={{ width: i === lines - 1 ? '60%' : width }} />)}</span>;
  }
  if (variant === 'list-item') {
    return (
      <span className="rr-li" aria-hidden="true">
        <span className="rr-skel rr-skel--circle" style={{ width: 40, height: 40, flex: 'none' }} />
        <span className="rr-li__body" style={{ gap: 8 }}><span className="rr-skel rr-skel--text" style={{ width: '70%' }} /><span className="rr-skel rr-skel--text" style={{ width: '45%' }} /></span>
      </span>
    );
  }
  return <span className={'rr-skel' + (variant === 'circle' ? ' rr-skel--circle' : '')} aria-hidden="true" style={{ width, height: height || (variant === 'circle' ? width : 80), borderRadius: radius }} />;
}
