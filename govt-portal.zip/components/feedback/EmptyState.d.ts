import { IconName } from '../core/Icon';
/** Shown when a list has nothing yet. Icon glyph only — no illustration downloads. */
export interface EmptyStateProps {
  icon?: IconName;
  title: string;
  body?: string;
  action?: React.ReactNode;
}
export declare function EmptyState(props: EmptyStateProps): JSX.Element;
