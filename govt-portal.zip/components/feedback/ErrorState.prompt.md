Replaces content when a load fails; always offer Retry.

```jsx
<ErrorState title="Could not load hospitals" onRetry={reload} secondary={<Button variant="text" icon="phone">Call 108</Button>} />
```
