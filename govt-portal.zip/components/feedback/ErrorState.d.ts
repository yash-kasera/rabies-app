/** Full-area error with a Retry button. Icon + text, never just a red colour. */
export interface ErrorStateProps {
  title?: string;
  body?: string;
  /** Short technical reference for support calls, e.g. "Error 504 · 10:42" */
  code?: string;
  onRetry?: () => void;
  retryLabel?: string;
  retryingLabel?: string;
  retrying?: boolean;
  secondary?: React.ReactNode;
}
export declare function ErrorState(props: ErrorStateProps): JSX.Element;
