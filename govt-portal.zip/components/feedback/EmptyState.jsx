import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function EmptyState({ icon = 'inbox', title, body, action }) {
  return (
    <div className="rr-state">
      <span className="rr-state__icon"><Icon name={icon} size={28} /></span>
      <h3 className="rr-state__title">{title}</h3>
      {body && <p className="rr-state__body">{body}</p>}
      {action && <div className="rr-state__actions">{action}</div>}
    </div>
  );
}
