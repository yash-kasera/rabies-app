import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { Button } from '../actions/Button.jsx';

export function ErrorState({ title = 'Could not load this page', body = 'Check your internet and try again.', code, onRetry, retryLabel = 'Try again', retryingLabel = 'Trying…', retrying, secondary }) {
  return (
    <div className="rr-state" role="alert">
      <span className="rr-state__icon rr-state__icon--error"><Icon name="triangle-alert" size={28} /></span>
      <h3 className="rr-state__title">{title}</h3>
      {body && <p className="rr-state__body">{body}</p>}
      {code && <span className="rr-state__code">{code}</span>}
      <div className="rr-state__actions">
        {onRetry && <Button variant="primary" icon="refresh-cw" onClick={onRetry} loading={retrying} loadingLabel={retryingLabel}>{retryLabel}</Button>}
        {secondary}
      </div>
    </div>
  );
}
