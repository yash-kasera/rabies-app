Offline strip. Pair with local caching — the app keeps working on saved data.

```jsx
<OfflineBanner lastSync="Last updated 10:42." onRetry={retry} />
<OfflineBanner online />
```
