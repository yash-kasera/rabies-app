import React from 'react';
import { Field, useFieldId } from './Field.jsx';

export function TextArea({ id, label, hint, error, optional, maxLength, value, defaultValue, onChange, rows = 4, ...rest }) {
  const fid = useFieldId(id);
  const [len, setLen] = React.useState(String(value ?? defaultValue ?? '').length);
  return (
    <Field id={fid} label={label} hint={hint} error={error} optional={optional}>
      <textarea id={fid} rows={rows} className="rr-input rr-textarea" maxLength={maxLength} value={value} defaultValue={defaultValue}
        onChange={e => { setLen(e.target.value.length); onChange && onChange(e); }} aria-invalid={error ? 'true' : undefined} aria-describedby={error ? fid + '-err' : hint ? fid + '-hint' : undefined} {...rest} />
      {maxLength ? <span className="rr-count" aria-live="polite">{len} / {maxLength}</span> : null}
    </Field>
  );
}
