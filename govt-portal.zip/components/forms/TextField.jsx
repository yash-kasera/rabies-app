import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { Field, useFieldId } from './Field.jsx';

export function TextField({ id, label, hint, error, optional, icon, loading, className, ...rest }) {
  const fid = useFieldId(id);
  return (
    <Field id={fid} label={label} hint={hint} error={error} optional={optional}>
      <div className="rr-control">
        {icon && <span className="rr-control__lead"><Icon name={icon} /></span>}
        <input id={fid} className={'rr-input' + (icon ? ' rr-input--icon' : '') + (className ? ' ' + className : '')} aria-invalid={error ? 'true' : undefined} aria-describedby={error ? fid + '-err' : hint ? fid + '-hint' : undefined} aria-busy={loading ? 'true' : undefined} {...rest} />
        {loading && <span className="rr-control__trail"><Icon name="loader" /></span>}
      </div>
    </Field>
  );
}
