/** Multi-line text input; vertical resize only. */
export interface TextAreaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  hint?: string;
  error?: string;
  optional?: boolean;
  /** Shows a live character counter when set */
  maxLength?: number;
}
export declare function TextArea(props: TextAreaProps): JSX.Element;
