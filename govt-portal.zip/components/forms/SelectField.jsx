import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { Field, useFieldId } from './Field.jsx';

export function SelectField({ id, label, hint, error, optional, options = [], placeholder, loading, loadingLabel = 'Loading…', disabled, ...rest }) {
  const fid = useFieldId(id);
  return (
    <Field id={fid} label={label} hint={hint} error={error} optional={optional}>
      <div className="rr-control">
        <select id={fid} className="rr-input rr-select" disabled={disabled || loading} aria-invalid={error ? 'true' : undefined} aria-describedby={error ? fid + '-err' : hint ? fid + '-hint' : undefined} aria-busy={loading ? 'true' : undefined} {...rest}>
          {loading ? <option>{loadingLabel}</option> : placeholder ? <option value="">{placeholder}</option> : null}
          {!loading && options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
        <span className="rr-control__trail"><Icon name={loading ? 'loader' : 'chevron-down'} /></span>
      </div>
    </Field>
  );
}
