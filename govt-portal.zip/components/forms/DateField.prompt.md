Date or date-time input using the native OS picker. Show format in the hint for low-literacy users.

```jsx
<DateField label="When did the bite happen?" mode="datetime" hint="Best guess is fine" max={nowIso} />
<DateField label="Next dose date" mode="date" />
```
- In Flutter, use showDatePicker / showTimePicker with the shared ColorScheme.
