Multi-line input for notes ("Describe where it happened").

```jsx
<TextArea label="Anything else the hospital should know?" optional maxLength={300} />
```
