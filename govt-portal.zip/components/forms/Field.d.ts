/** Label + control + hint/error wrapper used by every form control. Mark optional fields, not required ones. */
export interface FieldProps {
  id: string;
  label?: string;
  hint?: string;
  /** Error message; shown in red with an icon (never colour alone). */
  error?: string;
  optional?: boolean;
  optionalLabel?: string;
  children?: React.ReactNode;
}
export declare function Field(props: FieldProps): JSX.Element;
export declare function useFieldId(id?: string): string;
