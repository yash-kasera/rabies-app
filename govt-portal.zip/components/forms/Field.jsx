import React from 'react';
import { Icon } from '../core/Icon.jsx';

let _n = 0;
export function useFieldId(id) { const r = React.useRef(id || 'rr-f' + (++_n)); return r.current; }

export function Field({ id, label, hint, error, optional, optionalLabel = '(optional)', children }) {
  return (
    <div className="rr-field">
      {label && <label className="rr-label" htmlFor={id}>{label}{optional && <span className="rr-label__opt"> {optionalLabel}</span>}</label>}
      {children}
      {error ? <div className="rr-errortext" id={id + '-err'}><Icon name="circle-alert" size={16} />{error}</div>
        : hint ? <div className="rr-hint" id={id + '-hint'}>{hint}</div> : null}
    </div>
  );
}
