Labelled text input, 48px tall on mobile (40px desktop density), 16px text so Android never zooms.

```jsx
<TextField label="Mobile number" type="tel" inputMode="numeric" icon="phone" hint="We will send an SMS with your report number" />
<TextField label="Patient name" error="Please enter the patient's name" />
```
