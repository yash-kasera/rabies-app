import { IconName } from '../core/Icon';
/**
 * Single-line text input with label, hint and error.
 * @startingPoint section="Forms" subtitle="Inputs, selects, date pickers, textarea in every state" viewport="700x640"
 */
export interface TextFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  hint?: string;
  error?: string;
  optional?: boolean;
  icon?: IconName;
  /** Shows a static loader at the trailing edge (e.g. checking a phone number). */
  loading?: boolean;
}
export declare function TextField(props: TextFieldProps): JSX.Element;
