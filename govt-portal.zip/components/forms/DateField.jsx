import React from 'react';
import { Field, useFieldId } from './Field.jsx';

export function DateField({ id, label, hint, error, optional, mode = 'date', ...rest }) {
  const fid = useFieldId(id);
  const type = mode === 'datetime' ? 'datetime-local' : mode === 'time' ? 'time' : 'date';
  return (
    <Field id={fid} label={label} hint={hint} error={error} optional={optional}>
      <input id={fid} type={type} className="rr-input" aria-invalid={error ? 'true' : undefined} aria-describedby={error ? fid + '-err' : hint ? fid + '-hint' : undefined} {...rest} />
    </Field>
  );
}
