/** Date / date-time picker using the platform's native picker (no JS calendar download). */
export interface DateFieldProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: string;
  hint?: string;
  error?: string;
  optional?: boolean;
  /** date = dd/mm/yyyy, datetime = date + time (bite time), time = time only */
  mode?: 'date' | 'datetime' | 'time';
}
export declare function DateField(props: DateFieldProps): JSX.Element;
