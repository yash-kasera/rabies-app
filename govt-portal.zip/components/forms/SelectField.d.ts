/** Native <select> styled to match inputs — native keeps it fast and accessible on low-end Android. */
export interface SelectFieldProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  hint?: string;
  error?: string;
  optional?: boolean;
  options?: { value: string; label: string }[];
  placeholder?: string;
  loading?: boolean;
  loadingLabel?: string;
}
export declare function SelectField(props: SelectFieldProps): JSX.Element;
