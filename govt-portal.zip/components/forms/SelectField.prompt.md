Dropdown built on the native select element.

```jsx
<SelectField label="Which animal bit?" placeholder="Choose one" options={[{ value: 'dog', label: 'Dog' }, { value: 'cat', label: 'Cat' }, { value: 'monkey', label: 'Monkey' }]} />
<SelectField label="Hospital" loading loadingLabel="Loading hospitals…" />
```
