/**
 * Status pill: tone + icon + text (never colour alone). Severity badges add 1–4 level pips.
 * @startingPoint section="Status" subtitle="Case, severity, hospital and notice badges" viewport="700x360"
 */
export interface StatusBadgeProps {
  kind?: 'case' | 'severity' | 'hospital' | 'notice';
  /** case: reported|accepted|under_treatment|completed|cancelled
   *  severity: minor_scratch|bleeding_wound|deep_wound|multiple_bites
   *  hospital: active|inactive
   *  notice: outbreak_alert|general_awareness|new_hospital|maintenance_notice */
  value: string;
  lang?: 'en' | 'hi';
  size?: 'md' | 'lg';
  /** Override text (rare) */
  label?: string;
}
export declare function StatusBadge(props: StatusBadgeProps): JSX.Element;
export declare const STATUS: Record<string, Record<string, { tone: string; icon: string; en: string; hi: string; level?: number }>>;
