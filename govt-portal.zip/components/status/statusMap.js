// Single source of truth for status colours. Identical in all three products (mirror of tokens/tokens.json "status").
export const STATUS = {
  case: {
    reported:        { tone: 'warning', icon: 'circle-alert', en: 'Reported',        hi: 'दर्ज हुई' },
    accepted:        { tone: 'info',    icon: 'check',        en: 'Accepted',        hi: 'स्वीकार की गई' },
    under_treatment: { tone: 'primary', icon: 'syringe',      en: 'Under Treatment', hi: 'इलाज चल रहा है' },
    completed:       { tone: 'success', icon: 'circle-check', en: 'Completed',       hi: 'पूरा हुआ' },
    cancelled:       { tone: 'neutral', icon: 'circle-slash', en: 'Cancelled',       hi: 'रद्द' },
  },
  severity: {
    minor_scratch:  { tone: 'neutral',      level: 1, icon: 'info',           en: 'Minor Scratch',  hi: 'हल्की खरोंच' },
    bleeding_wound: { tone: 'warning',      level: 2, icon: 'circle-alert',   en: 'Bleeding Wound', hi: 'खून निकलता घाव' },
    deep_wound:     { tone: 'orange',       level: 3, icon: 'triangle-alert', en: 'Deep Wound',     hi: 'गहरा घाव' },
    multiple_bites: { tone: 'danger-solid', level: 4, icon: 'siren',          en: 'Multiple Bites', hi: 'कई जगह काटा' },
  },
  hospital: {
    active:   { tone: 'success', icon: 'circle-check', en: 'Active',   hi: 'सक्रिय' },
    inactive: { tone: 'neutral', icon: 'circle-slash', en: 'Inactive', hi: 'निष्क्रिय' },
  },
  notice: {
    outbreak_alert:     { tone: 'danger',  icon: 'siren',     en: 'Outbreak Alert',     hi: 'प्रकोप चेतावनी' },
    general_awareness:  { tone: 'info',    icon: 'megaphone', en: 'General Awareness',  hi: 'सामान्य जानकारी' },
    new_hospital:       { tone: 'success', icon: 'hospital',  en: 'New Hospital',       hi: 'नया अस्पताल' },
    maintenance_notice: { tone: 'warning', icon: 'wrench',    en: 'Maintenance Notice', hi: 'रखरखाव सूचना' },
  },
};
