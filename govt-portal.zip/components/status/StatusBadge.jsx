import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { STATUS } from './statusMap.js';

export function StatusBadge({ kind = 'case', value, lang = 'en', size = 'md', label }) {
  const s = (STATUS[kind] || {})[value] || { tone: 'neutral', icon: 'circle-help', en: String(value), hi: String(value) };
  const text = label || (lang === 'hi' ? s.hi : s.en);
  return (
    <span className={'rr-badge rr-badge--' + s.tone + (size === 'lg' ? ' rr-badge--lg' : '')}>
      <Icon name={s.icon} size={size === 'lg' ? 18 : 16} />
      <span>{text}</span>
      {s.level ? (
        <span className="rr-pips" role="img" aria-label={(lang === 'hi' ? 'स्तर ' : 'Level ') + s.level + ' / 4'}>
          {[1, 2, 3, 4].map(i => <span key={i} className={'rr-pip' + (i <= s.level ? ' is-on' : '')} />)}
        </span>
      ) : null}
    </span>
  );
}
