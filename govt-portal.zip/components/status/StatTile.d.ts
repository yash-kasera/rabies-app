import { IconName } from '../core/Icon';
/** KPI tile for dashboards: label, big tabular number, optional trend line. */
export interface StatTileProps {
  label: string;
  value: React.ReactNode;
  sub?: string;
  /** up-bad (red + icon) e.g. cases rising; down-good (green + icon); omit for neutral */
  trend?: 'up-bad' | 'down-good';
  icon?: IconName;
  loading?: boolean;
  /** Makes the tile a button that filters the view below */
  onClick?: () => void;
}
export declare function StatTile(props: StatTileProps): JSX.Element;
