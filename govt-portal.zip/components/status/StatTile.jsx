import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function StatTile({ label, value, sub, trend, icon, loading, onClick }) {
  const Tag = onClick ? 'button' : 'div';
  const trendCls = trend === 'up-bad' ? ' rr-stat__sub--up-bad' : trend === 'down-good' ? ' rr-stat__sub--down-good' : '';
  const trendIcon = trend === 'up-bad' ? 'triangle-alert' : trend === 'down-good' ? 'circle-check' : null;
  return (
    <Tag className={'rr-card rr-stat' + (onClick ? ' rr-card--interactive' : '')} onClick={onClick} aria-busy={loading ? 'true' : undefined}>
      <div className="rr-stat__top">
        <span className="rr-stat__label">{label}</span>
        {icon && <span className="rr-stat__icon"><Icon name={icon} size={18} /></span>}
      </div>
      {loading ? <span className="rr-skel" style={{ width: 72, height: 32, margin: '4px 0' }} />
        : <span className="rr-stat__value">{value}</span>}
      {sub && !loading && <span className={'rr-stat__sub' + trendCls}>{trendIcon && <Icon name={trendIcon} size={16} />}{sub}</span>}
    </Tag>
  );
}
