Dashboard KPI tile. Trend meaning is carried by text + icon, not colour alone.

```jsx
<StatTile label="New reports today" value="42" sub="+12 vs yesterday" trend="up-bad" icon="file-text" />
<StatTile label="Vaccine stock (ARV)" value="318 vials" loading />
```
