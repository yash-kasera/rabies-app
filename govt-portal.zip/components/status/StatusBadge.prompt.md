Pill badge for every status in the platform; colours come from one shared map so all three products match.

```jsx
<StatusBadge kind="case" value="under_treatment" />
<StatusBadge kind="severity" value="multiple_bites" lang="hi" />
<StatusBadge kind="hospital" value="inactive" />
<StatusBadge kind="notice" value="outbreak_alert" size="lg" />
```
