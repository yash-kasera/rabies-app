Pill-shaped action button; one primary per screen, emergency only for "Report a bite" / "Call 108".

```jsx
<Button variant="emergency" size="lg" icon="siren" block>Report an animal bite</Button>
<Button variant="primary" loading loadingLabel="Sending…">Send report</Button>
<Button variant="secondary" icon="phone">Call hospital</Button>
<Button variant="text">Skip for now</Button>
```

- Variants: primary, secondary, emergency, danger, text. Sizes: sm (desktop only), md, lg.
- Loading shows a static loader icon and a verb-ing label ("Sending…", "भेज रहे हैं…").
- Never set a fixed width; use `block` for full-width mobile CTAs.
