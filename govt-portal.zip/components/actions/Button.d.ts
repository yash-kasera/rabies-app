import { IconName } from '../core/Icon';
/**
 * Pill button. Width always hugs content (never fixed) so Hindi labels wrap instead of truncating.
 * @startingPoint section="Actions" subtitle="Primary, secondary, emergency, text buttons with all states" viewport="700x520"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** emergency = bite reporting / SOS only. danger = destructive (cancel report, deactivate hospital). */
  variant?: 'primary' | 'secondary' | 'emergency' | 'danger' | 'text';
  /** lg = 56px mobile hero CTA; md = 48px (40px in desktop density); sm = desktop-only toolbars */
  size?: 'sm' | 'md' | 'lg';
  block?: boolean;
  icon?: IconName;
  iconRight?: IconName;
  /** Shows a static loader glyph + loadingLabel; disables the button. No spinning animation. */
  loading?: boolean;
  loadingLabel?: string;
  disabled?: boolean;
  children?: React.ReactNode;
}
export declare function Button(props: ButtonProps): JSX.Element;
