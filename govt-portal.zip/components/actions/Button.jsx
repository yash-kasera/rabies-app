import React from 'react';
import { Icon } from '../core/Icon.jsx';
const cx = (...a) => a.filter(Boolean).join(' ');

export function Button({ variant = 'primary', size = 'md', block, icon, iconRight, loading, loadingLabel, disabled, type = 'button', className, children, ...rest }) {
  return (
    <button type={type} className={cx('rr-btn', 'rr-btn--' + variant, size !== 'md' && 'rr-btn--' + size, block && 'rr-btn--block', loading && 'is-loading', className)}
      disabled={disabled || loading} aria-busy={loading ? 'true' : undefined} {...rest}>
      {loading ? <Icon name="loader" size={20} /> : icon ? <Icon name={icon} size={size === 'lg' ? 24 : 20} /> : null}
      <span className="rr-btn__label">{loading && loadingLabel ? loadingLabel : children}</span>
      {iconRight && !loading ? <Icon name={iconRight} size={20} /> : null}
    </button>
  );
}
