export type IconName = 'activity'|'arrow-left'|'bell'|'book-open'|'building-2'|'calendar'|'camera'|'check'|'chevron-down'|'chevron-left'|'chevron-right'|'circle-alert'|'circle-check'|'circle-help'|'circle-slash'|'circle-x'|'clipboard-list'|'clock'|'download'|'eye'|'file-text'|'filter'|'hospital'|'house'|'inbox'|'info'|'layout-dashboard'|'list'|'loader'|'log-out'|'map-pin'|'map'|'megaphone'|'menu'|'navigation'|'pencil'|'phone'|'plus'|'refresh-cw'|'search'|'settings'|'shield-check'|'siren'|'syringe'|'triangle-alert'|'user'|'users'|'wifi-off'|'wrench'|'x';
/** Lucide outline icon rendered inline (no network request). Decorative unless `label` is given. */
export interface IconProps {
  name: IconName;
  /** px; 20 default, 16 in badges, 24 in nav */
  size?: number;
  /** Accessible name. Omit when the icon sits next to visible text. */
  label?: string;
  className?: string;
  style?: React.CSSProperties;
}
export declare function Icon(props: IconProps): JSX.Element;
