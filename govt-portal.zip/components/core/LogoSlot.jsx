import React from 'react';

export function LogoSlot({ size = 40, src, alt = 'Department logo', label = 'DEPT LOGO' }) {
  return (
    <span className="rr-logo-slot" style={{ width: size, height: size }} role={src ? undefined : 'img'} aria-label={src ? undefined : alt}>
      {src ? <img src={src} alt={alt} /> : (size >= 36 ? label : null)}
    </span>
  );
}
