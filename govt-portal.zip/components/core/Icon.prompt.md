Inline outline icon (Lucide subset, stroke 2). Always pair with a visible text label for critical actions.

```jsx
<Icon name="phone" />
<Icon name="triangle-alert" size={16} />
<Icon name="x" label="Close" />
```

- Sizes: 16 (badges), 20 (buttons, fields), 24 (bottom nav, app bar).
- Colour inherits `currentColor`.
