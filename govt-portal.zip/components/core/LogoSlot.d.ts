/** Placeholder slot for the issuing department's logo. Never place a real government emblem here without authorisation. */
export interface LogoSlotProps {
  /** Square size in px. Default 40. */
  size?: number;
  /** Supplied logo file (SVG/PNG, < 10 KB). Omit to show the dashed placeholder. */
  src?: string;
  alt?: string;
  label?: string;
}
export declare function LogoSlot(props: LogoSlotProps): JSX.Element;
