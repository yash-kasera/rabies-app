import React from 'react';
import { ICONS } from './iconData.js';

export function Icon({ name, size = 20, label, className, style }) {
  const inner = ICONS[name] || '';
  return (
    <svg className={'rr-icon' + (className ? ' ' + className : '')} width={size} height={size} viewBox="0 0 24 24"
      fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
      role={label ? 'img' : undefined} aria-label={label} aria-hidden={label ? undefined : 'true'} focusable="false"
      style={style} dangerouslySetInnerHTML={{ __html: inner }} />
  );
}
