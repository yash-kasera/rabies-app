import { IconName } from './Icon';
/** Two-to-three option switch. Canonical use: List / Map view toggle (list is always the default). */
export interface SegmentedToggleProps {
  options: { value: string; label: string; icon?: IconName }[];
  value: string;
  onChange?: (value: string) => void;
  /** Group label for screen readers */
  label?: string;
}
export declare function SegmentedToggle(props: SegmentedToggleProps): JSX.Element;
