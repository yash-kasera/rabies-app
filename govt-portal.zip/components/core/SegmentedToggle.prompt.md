Pill segmented switch; use for List / Map so the heavy map is only loaded on demand.

```jsx
<SegmentedToggle label="View" value={view} onChange={setView}
  options={[{ value: 'list', label: 'List', icon: 'list' }, { value: 'map', label: 'Map', icon: 'map' }]} />
```
