import React from 'react';
import { Icon } from './Icon.jsx';

export function SegmentedToggle({ options, value, onChange, label }) {
  return (
    <div className="rr-seg" role="group" aria-label={label}>
      {options.map(o => (
        <button key={o.value} type="button" className="rr-seg__btn" aria-pressed={o.value === value ? 'true' : 'false'} onClick={() => onChange && onChange(o.value)}>
          {o.icon && <Icon name={o.icon} size={18} />}{o.label}
        </button>
      ))}
    </div>
  );
}
