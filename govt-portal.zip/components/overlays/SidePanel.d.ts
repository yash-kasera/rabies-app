/** Right-edge detail panel for portals (case detail, hospital edit). 480px max, full width on small screens. Appears instantly — no slide animation. */
export interface SidePanelProps {
  open?: boolean;
  title: string;
  subtitle?: React.ReactNode;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  onClose?: () => void;
  closeLabel?: string;
  inline?: boolean;
  style?: React.CSSProperties;
}
export declare function SidePanel(props: SidePanelProps): JSX.Element | null;
