import React from 'react';
import { Icon } from '../core/Icon.jsx';

const ICON = { success: 'circle-check', error: 'circle-alert', info: 'info' };

export function Toast({ tone = 'info', message, actionLabel, onAction, onClose, closeLabel = 'Dismiss' }) {
  return (
    <div className="rr-toast" role={tone === 'error' ? 'alert' : 'status'}>
      <Icon name={ICON[tone]} className={'rr-toast__icon rr-toast__icon--' + tone} />
      <div className="rr-toast__msg">{message}</div>
      {actionLabel && <button type="button" className="rr-toast__action" onClick={onAction}>{actionLabel}</button>}
      {onClose && !actionLabel && <button type="button" className="rr-toast__action" onClick={onClose} aria-label={closeLabel}><Icon name="x" size={18} /></button>}
    </div>
  );
}

export function ToastRegion({ children }) {
  return <div className="rr-toast-region" aria-live="polite">{children}</div>;
}
