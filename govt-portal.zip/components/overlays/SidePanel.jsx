import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function SidePanel({ open = true, title, subtitle, children, footer, onClose, closeLabel = 'Close', inline, style }) {
  if (!open) return null;
  const panel = (
    <aside className={'rr-panel' + (inline ? ' rr-panel--inline' : '')} role={inline ? 'region' : 'dialog'} aria-label={title} style={style}>
      <div className="rr-panel__head">
        <div className="rr-panel__titles">
          <h2 className="rr-panel__title">{title}</h2>
          {subtitle && <span className="rr-panel__sub">{subtitle}</span>}
        </div>
        {onClose && <button type="button" className="rr-iconbtn" onClick={onClose} aria-label={closeLabel}><Icon name="x" /></button>}
      </div>
      <div className="rr-panel__body">{children}</div>
      {footer && <div className="rr-panel__foot">{footer}</div>}
    </aside>
  );
  return inline ? panel : <>{<div className="rr-panel-scrim" onClick={onClose} />}{panel}</>;
}
