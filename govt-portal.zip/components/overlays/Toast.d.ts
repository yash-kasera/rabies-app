/** Short confirmation on the inverse surface. Auto-dismiss after 6s unless it has an action; errors stay until dismissed. */
export interface ToastProps {
  tone?: 'success' | 'error' | 'info';
  message: React.ReactNode;
  actionLabel?: string;
  onAction?: () => void;
  onClose?: () => void;
  closeLabel?: string;
}
export declare function Toast(props: ToastProps): JSX.Element;
export declare function ToastRegion(props: { children?: React.ReactNode }): JSX.Element;
