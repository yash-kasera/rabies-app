import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function Dialog({ open = true, title, icon, tone = 'default', children, actions, onClose, closeLabel = 'Close', inline }) {
  if (!open) return null;
  const box = (
    <div className="rr-dialog" role="dialog" aria-modal={inline ? undefined : 'true'} aria-labelledby="rr-dlg-title" onClick={e => e.stopPropagation()}>
      <div className="rr-dialog__head">
        {icon && <span className={'rr-dialog__icon' + (tone !== 'default' ? ' rr-dialog__icon--' + tone : '')}><Icon name={icon} /></span>}
        <h2 className="rr-dialog__title" id="rr-dlg-title">{title}</h2>
        {onClose && <button type="button" className="rr-iconbtn" onClick={onClose} aria-label={closeLabel}><Icon name="x" /></button>}
      </div>
      <div className="rr-dialog__body">{children}</div>
      {actions && <div className="rr-dialog__actions">{actions}</div>}
    </div>
  );
  return inline ? box : <div className="rr-scrim" onClick={onClose}>{box}</div>;
}
