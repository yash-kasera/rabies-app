import { IconName } from '../core/Icon';
/** Modal dialog on a flat scrim (no blur). Actions wrap and stack full-width under 480px. */
export interface DialogProps {
  open?: boolean;
  title: string;
  icon?: IconName;
  tone?: 'default' | 'danger' | 'emergency';
  children?: React.ReactNode;
  /** Buttons, secondary first then primary (primary ends up right on desktop, top on mobile) */
  actions?: React.ReactNode;
  onClose?: () => void;
  closeLabel?: string;
  /** Render without scrim/fixed positioning (documentation, previews) */
  inline?: boolean;
}
export declare function Dialog(props: DialogProps): JSX.Element | null;
