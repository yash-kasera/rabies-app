Confirmation or short task dialog. Titles are questions in plain words.

```jsx
<Dialog title="Cancel this report?" icon="triangle-alert" tone="danger" onClose={close}
  actions={<><Button variant="secondary" onClick={close}>Keep report</Button><Button variant="danger">Yes, cancel</Button></>}>
  The hospital will be told you are not coming.
</Dialog>
```
