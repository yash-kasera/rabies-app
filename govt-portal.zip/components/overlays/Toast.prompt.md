Bottom toast for outcomes ("Report sent"). Place inside <ToastRegion> at app root.

```jsx
<ToastRegion><Toast tone="success" message="Report sent. Number RR-0142." actionLabel="View" onAction={…} /></ToastRegion>
```
