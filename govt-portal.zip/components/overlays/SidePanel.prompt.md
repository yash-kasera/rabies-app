Detail panel opened from a table row; keeps the list visible behind it.

```jsx
<SidePanel title="Report RR-2026-0142" subtitle="Reported 10:42 today" onClose={close}
  footer={<><Button variant="secondary">Reject</Button><Button>Accept patient</Button></>}>…</SidePanel>
```
