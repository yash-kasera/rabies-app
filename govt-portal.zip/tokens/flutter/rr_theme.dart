// Rabies Response — Flutter Material 3 theme. Generated from tokens/tokens.json. Place in lib/theme/rr_theme.dart.
// Usage: MaterialApp(theme: RRTheme.light(), darkTheme: RRTheme.dark(), themeMode: ThemeMode.system)
// Fonts: no bundled font — Roboto (Latin) + Noto Sans Devanagari (Hindi) are Android system fonts.
import 'package:flutter/material.dart';

@immutable
class RRColors extends ThemeExtension<RRColors> {
  final Color background;
  final Color surface;
  final Color surfaceAlt;
  final Color border;
  final Color borderStrong;
  final Color textPrimary;
  final Color textSecondary;
  final Color textDisabled;
  final Color primary;
  final Color primaryHover;
  final Color primaryPressed;
  final Color onPrimary;
  final Color primaryContainer;
  final Color onPrimaryContainer;
  final Color secondary;
  final Color secondaryContainer;
  final Color onSecondaryContainer;
  final Color emergency;
  final Color emergencyHover;
  final Color onEmergency;
  final Color emergencyContainer;
  final Color onEmergencyContainer;
  final Color danger;
  final Color dangerContainer;
  final Color onDangerContainer;
  final Color warning;
  final Color warningContainer;
  final Color onWarningContainer;
  final Color orange;
  final Color orangeContainer;
  final Color onOrangeContainer;
  final Color success;
  final Color successContainer;
  final Color onSuccessContainer;
  final Color info;
  final Color infoContainer;
  final Color onInfoContainer;
  final Color neutral;
  final Color neutralContainer;
  final Color onNeutralContainer;
  final Color focus;
  final Color inverseSurface;
  final Color onInverse;
  const RRColors({required this.background, required this.surface, required this.surfaceAlt, required this.border, required this.borderStrong, required this.textPrimary, required this.textSecondary, required this.textDisabled, required this.primary, required this.primaryHover, required this.primaryPressed, required this.onPrimary, required this.primaryContainer, required this.onPrimaryContainer, required this.secondary, required this.secondaryContainer, required this.onSecondaryContainer, required this.emergency, required this.emergencyHover, required this.onEmergency, required this.emergencyContainer, required this.onEmergencyContainer, required this.danger, required this.dangerContainer, required this.onDangerContainer, required this.warning, required this.warningContainer, required this.onWarningContainer, required this.orange, required this.orangeContainer, required this.onOrangeContainer, required this.success, required this.successContainer, required this.onSuccessContainer, required this.info, required this.infoContainer, required this.onInfoContainer, required this.neutral, required this.neutralContainer, required this.onNeutralContainer, required this.focus, required this.inverseSurface, required this.onInverse});

  static const light = RRColors(
    background: Color(0xFFF7F3EC),
    surface: Color(0xFFFFFFFF),
    surfaceAlt: Color(0xFFF0EADF),
    border: Color(0xFFDED5C6),
    borderStrong: Color(0xFF8A7F6E),
    textPrimary: Color(0xFF1B2428),
    textSecondary: Color(0xFF4D5A60),
    textDisabled: Color(0xFF7A8286),
    primary: Color(0xFF1E4D5A),
    primaryHover: Color(0xFF173F4A),
    primaryPressed: Color(0xFF11323B),
    onPrimary: Color(0xFFFFFFFF),
    primaryContainer: Color(0xFFDDEBEC),
    onPrimaryContainer: Color(0xFF0F3440),
    secondary: Color(0xFF3E6A5A),
    secondaryContainer: Color(0xFFE0ECE5),
    onSecondaryContainer: Color(0xFF173A2E),
    emergency: Color(0xFFC0271D),
    emergencyHover: Color(0xFFA11F17),
    onEmergency: Color(0xFFFFFFFF),
    emergencyContainer: Color(0xFFFDE7E4),
    onEmergencyContainer: Color(0xFF7A1610),
    danger: Color(0xFFB3261E),
    dangerContainer: Color(0xFFFCE8E6),
    onDangerContainer: Color(0xFF7A1712),
    warning: Color(0xFF8A5300),
    warningContainer: Color(0xFFFFF0D1),
    onWarningContainer: Color(0xFF5C3700),
    orange: Color(0xFF9A3F0C),
    orangeContainer: Color(0xFFFDE6D6),
    onOrangeContainer: Color(0xFF6B2A06),
    success: Color(0xFF1E6B3A),
    successContainer: Color(0xFFE2F2E6),
    onSuccessContainer: Color(0xFF114625),
    info: Color(0xFF1F5A96),
    infoContainer: Color(0xFFE3EDF8),
    onInfoContainer: Color(0xFF123D69),
    neutral: Color(0xFF56626A),
    neutralContainer: Color(0xFFEDEAE4),
    onNeutralContainer: Color(0xFF333D43),
    focus: Color(0xFF1F5A96),
    inverseSurface: Color(0xFF1B2428),
    onInverse: Color(0xFFF7F3EC),
  );

  static const dark = RRColors(
    background: Color(0xFF0F1518),
    surface: Color(0xFF172024),
    surfaceAlt: Color(0xFF1F2A2F),
    border: Color(0xFF2E3B42),
    borderStrong: Color(0xFF71818A),
    textPrimary: Color(0xFFEDF1F2),
    textSecondary: Color(0xFFB0BCC2),
    textDisabled: Color(0xFF6F7C82),
    primary: Color(0xFF86C9D3),
    primaryHover: Color(0xFFA2D7DF),
    primaryPressed: Color(0xFFBFE4EA),
    onPrimary: Color(0xFF06323B),
    primaryContainer: Color(0xFF1C4852),
    onPrimaryContainer: Color(0xFFCDEEF3),
    secondary: Color(0xFF9CCBB6),
    secondaryContainer: Color(0xFF1E3B31),
    onSecondaryContainer: Color(0xFFCFEBDD),
    emergency: Color(0xFFCC3328),
    emergencyHover: Color(0xFFB42A20),
    onEmergency: Color(0xFFFFFFFF),
    emergencyContainer: Color(0xFF45140F),
    onEmergencyContainer: Color(0xFFFFD9D3),
    danger: Color(0xFFFF8A7F),
    dangerContainer: Color(0xFF47150F),
    onDangerContainer: Color(0xFFFFDAD4),
    warning: Color(0xFFF0C064),
    warningContainer: Color(0xFF3A2A08),
    onWarningContainer: Color(0xFFFFE3A6),
    orange: Color(0xFFF5A06B),
    orangeContainer: Color(0xFF40200A),
    onOrangeContainer: Color(0xFFFFDCC4),
    success: Color(0xFF7FD49B),
    successContainer: Color(0xFF143722),
    onSuccessContainer: Color(0xFFC5EFD1),
    info: Color(0xFF93BEF0),
    infoContainer: Color(0xFF152D4A),
    onInfoContainer: Color(0xFFD4E5FA),
    neutral: Color(0xFFAAB5BA),
    neutralContainer: Color(0xFF263136),
    onNeutralContainer: Color(0xFFDDE3E6),
    focus: Color(0xFF93BEF0),
    inverseSurface: Color(0xFFEDF1F2),
    onInverse: Color(0xFF172024),
  );

  @override
  RRColors copyWith() => this;
  @override
  RRColors lerp(ThemeExtension<RRColors>? other, double t) => (t < 0.5 || other is! RRColors) ? this : other;
}

/// Shared status map — identical to components/status/statusMap.js.
enum RRTone { neutral, info, primary, warning, orange, success, danger, dangerSolid }
class RRStatus {
  final RRTone tone; final IconData icon; final String en; final String hi; final int? level;
  const RRStatus(this.tone, this.icon, this.en, this.hi, [this.level]);
  // Lucide icons via package lucide_icons_flutter (outline). Swap for Icons.* outlined if preferred.
  static const case = <String, RRStatus>{
    'reported': RRStatus(RRTone.warning, Icons.error_outline, 'Reported', 'दर्ज हुई'),
    'accepted': RRStatus(RRTone.info, Icons.check, 'Accepted', 'स्वीकार की गई'),
    'under_treatment': RRStatus(RRTone.primary, Icons.vaccines_outlined, 'Under Treatment', 'इलाज चल रहा है'),
    'completed': RRStatus(RRTone.success, Icons.check_circle_outline, 'Completed', 'पूरा हुआ'),
    'cancelled': RRStatus(RRTone.neutral, Icons.block, 'Cancelled', 'रद्द'),
  };
  static const severity = <String, RRStatus>{
    'minor_scratch': RRStatus(RRTone.neutral, Icons.info_outline, 'Minor Scratch', 'हल्की खरोंच', 1),
    'bleeding_wound': RRStatus(RRTone.warning, Icons.error_outline, 'Bleeding Wound', 'खून निकलता घाव', 2),
    'deep_wound': RRStatus(RRTone.orange, Icons.warning_amber, 'Deep Wound', 'गहरा घाव', 3),
    'multiple_bites': RRStatus(RRTone.dangerSolid, Icons.emergency_outlined, 'Multiple Bites', 'कई जगह काटा', 4),
  };
  static const hospital = <String, RRStatus>{
    'active': RRStatus(RRTone.success, Icons.check_circle_outline, 'Active', 'सक्रिय'),
    'inactive': RRStatus(RRTone.neutral, Icons.block, 'Inactive', 'निष्क्रिय'),
  };
  static const notice = <String, RRStatus>{
    'outbreak_alert': RRStatus(RRTone.danger, Icons.emergency_outlined, 'Outbreak Alert', 'प्रकोप चेतावनी'),
    'general_awareness': RRStatus(RRTone.info, Icons.campaign_outlined, 'General Awareness', 'सामान्य जानकारी'),
    'new_hospital': RRStatus(RRTone.success, Icons.local_hospital_outlined, 'New Hospital', 'नया अस्पताल'),
    'maintenance_notice': RRStatus(RRTone.warning, Icons.build_outlined, 'Maintenance Notice', 'रखरखाव सूचना'),
  };

  /// (background, foreground, border) for a tone.
  static (Color, Color, Color) colors(RRColors c, RRTone t) => switch (t) {
    RRTone.neutral => (c.neutralContainer, c.onNeutralContainer, c.borderStrong),
    RRTone.info => (c.infoContainer, c.onInfoContainer, c.info),
    RRTone.primary => (c.primaryContainer, c.onPrimaryContainer, c.primary),
    RRTone.warning => (c.warningContainer, c.onWarningContainer, c.warning),
    RRTone.orange => (c.orangeContainer, c.onOrangeContainer, c.orange),
    RRTone.success => (c.successContainer, c.onSuccessContainer, c.success),
    RRTone.danger => (c.dangerContainer, c.onDangerContainer, c.danger),
    RRTone.dangerSolid => (c.emergency, c.onEmergency, c.emergency),
  };
}

class RRSpace { static const s1 = 4.0, s2 = 8.0, s3 = 12.0, s4 = 16.0, s5 = 20.0, s6 = 24.0, s8 = 32.0, s10 = 40.0, s12 = 48.0, s16 = 64.0; }
class RRRadius { static const xs = 4.0, sm = 8.0, md = 12.0, lg = 16.0, xl = 24.0, pill = 999.0; }
class RRMotion { static const fast = Duration(milliseconds: 120), base = Duration(milliseconds: 150); static const curve = Cubic(0.2, 0, 0, 1); }

class RRTheme {
  static ThemeData light() => _build(Brightness.light, RRColors.light);
  static ThemeData dark() => _build(Brightness.dark, RRColors.dark);

  static ThemeData _build(Brightness b, RRColors c) {
    final scheme = ColorScheme(
      brightness: b,
      primary: c.primary, onPrimary: c.onPrimary,
      primaryContainer: c.primaryContainer, onPrimaryContainer: c.onPrimaryContainer,
      secondary: c.secondary, onSecondary: b == Brightness.light ? const Color(0xFFFFFFFF) : c.background,
      secondaryContainer: c.secondaryContainer, onSecondaryContainer: c.onSecondaryContainer,
      tertiary: c.emergency, onTertiary: c.onEmergency,               // tertiary = emergency (SOS / report bite)
      tertiaryContainer: c.emergencyContainer, onTertiaryContainer: c.onEmergencyContainer,
      error: c.danger, onError: b == Brightness.light ? const Color(0xFFFFFFFF) : c.background,
      errorContainer: c.dangerContainer, onErrorContainer: c.onDangerContainer,
      surface: c.surface, onSurface: c.textPrimary, onSurfaceVariant: c.textSecondary,
      surfaceContainerLowest: c.surface, surfaceContainerLow: c.background, surfaceContainer: c.surfaceAlt,
      surfaceContainerHigh: c.surfaceAlt, surfaceContainerHighest: c.surfaceAlt,
      outline: c.borderStrong, outlineVariant: c.border,
      inverseSurface: c.inverseSurface, onInverseSurface: c.onInverse, inversePrimary: b == Brightness.light ? const Color(0xFF8FD0DA) : const Color(0xFF1E4D5A),
      shadow: const Color(0x1A1B2428), scrim: const Color(0x8F11171A), surfaceTint: Colors.transparent,
    );
    const w6 = FontWeight.w600;
    final text = TextTheme(
      headlineMedium: const TextStyle(fontSize: 28, height: 36 / 28, fontWeight: w6),
      headlineSmall: const TextStyle(fontSize: 24, height: 32 / 24, fontWeight: w6),
      titleLarge: const TextStyle(fontSize: 20, height: 28 / 20, fontWeight: w6),
      titleMedium: const TextStyle(fontSize: 18, height: 26 / 18, fontWeight: w6),
      bodyLarge: const TextStyle(fontSize: 18, height: 28 / 18),
      bodyMedium: const TextStyle(fontSize: 16, height: 24 / 16),
      bodySmall: const TextStyle(fontSize: 14, height: 20 / 14),
      labelLarge: const TextStyle(fontSize: 16, height: 22 / 16, fontWeight: w6),
      labelMedium: const TextStyle(fontSize: 14, height: 20 / 14, fontWeight: w6),
    ).apply(bodyColor: c.textPrimary, displayColor: c.textPrimary);
    final pill = const StadiumBorder();
    final btnPad = const EdgeInsets.symmetric(horizontal: 20, vertical: 12);
    const minBtn = Size(48, 48);
    OutlineInputBorder ob(Color col, [double w = 1]) => OutlineInputBorder(borderRadius: BorderRadius.circular(RRRadius.md), borderSide: BorderSide(color: col, width: w));
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: c.background,
      textTheme: text,
      extensions: [c],
      splashFactory: NoSplash.splashFactory,          // no ripple animation; pressed = colour change only
      pageTransitionsTheme: const PageTransitionsTheme(builders: { TargetPlatform.android: FadeForwardsPageTransitionsBuilder() }),
      materialTapTargetSize: MaterialTapTargetSize.padded,
      visualDensity: VisualDensity.standard,
      dividerTheme: DividerThemeData(color: c.border, thickness: 1, space: 1),
      appBarTheme: AppBarTheme(backgroundColor: c.surface, foregroundColor: c.textPrimary, elevation: 0, scrolledUnderElevation: 0, shape: Border(bottom: BorderSide(color: c.border))),
      cardTheme: CardThemeData(color: c.surface, elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(RRRadius.lg), side: BorderSide(color: c.border))),
      filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(minimumSize: minBtn, padding: btnPad, shape: pill, textStyle: text.labelLarge, animationDuration: RRMotion.fast)),
      outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(minimumSize: minBtn, padding: btnPad, shape: pill, foregroundColor: c.primary, side: BorderSide(color: c.borderStrong), textStyle: text.labelLarge)),
      textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(minimumSize: minBtn, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12), shape: pill, foregroundColor: c.primary, textStyle: text.labelLarge)),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: c.surface, isDense: false,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        border: ob(c.borderStrong), enabledBorder: ob(c.borderStrong), focusedBorder: ob(c.focus, 2),
        errorBorder: ob(c.danger, 2), focusedErrorBorder: ob(c.danger, 2), disabledBorder: ob(c.border),
        labelStyle: text.labelLarge, floatingLabelBehavior: FloatingLabelBehavior.always,
        helperStyle: text.bodySmall?.copyWith(color: c.textSecondary), errorStyle: text.bodySmall?.copyWith(color: c.danger, fontWeight: w6), errorMaxLines: 3, helperMaxLines: 3,
      ),
      dialogTheme: DialogThemeData(backgroundColor: c.surface, elevation: 1, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(RRRadius.lg), side: BorderSide(color: c.border))),
      snackBarTheme: SnackBarThemeData(backgroundColor: c.inverseSurface, contentTextStyle: text.bodyMedium?.copyWith(color: c.onInverse), actionTextColor: scheme.inversePrimary, behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(RRRadius.md)), elevation: 1),
      navigationBarTheme: NavigationBarThemeData(backgroundColor: c.surface, indicatorColor: c.primaryContainer, elevation: 0, height: 72, labelBehavior: NavigationDestinationLabelBehavior.alwaysShow),
      chipTheme: ChipThemeData(shape: pill, side: BorderSide(color: c.border), backgroundColor: c.surface),
      progressIndicatorTheme: ProgressIndicatorThemeData(color: c.primary, linearTrackColor: c.surfaceAlt),
    );
  }
}
