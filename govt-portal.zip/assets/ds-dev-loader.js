// Preview helper: resolves the compiled design-system bundle if present; otherwise compiles components/*.jsx in the browser.
// window.rrReady -> Promise<{ Button, StatusBadge, ... }>
(function () {
  var me = document.currentScript && document.currentScript.src;
  var root = me ? me.replace(/assets\/ds-dev-loader\.js.*$/, '') : '../';
  var FILES = ['core/iconData.js', 'core/Icon.jsx', 'core/LogoSlot.jsx', 'core/SegmentedToggle.jsx', 'actions/Button.jsx',
    'forms/Field.jsx', 'forms/TextField.jsx', 'forms/SelectField.jsx', 'forms/DateField.jsx', 'forms/TextArea.jsx',
    'status/statusMap.js', 'status/StatusBadge.jsx', 'status/StatTile.jsx', 'surfaces/Card.jsx', 'surfaces/ListItem.jsx',
    'surfaces/DataTable.jsx', 'overlays/Dialog.jsx', 'overlays/SidePanel.jsx', 'overlays/Toast.jsx',
    'feedback/EmptyState.jsx', 'feedback/ErrorState.jsx', 'feedback/Skeleton.jsx', 'feedback/OfflineBanner.jsx'];
  function findBundle() {
    for (var k in window) { try { var v = window[k]; if (v && v.Button && v.StatusBadge && v.DataTable) return v; } catch (e) {} }
    return null;
  }
  function compile(texts) {
    var out = 'var __E = {};\n';
    texts.forEach(function (src) {
      var names = [];
      src = src.replace(/^import\s+React[^;]*;?\s*$/mg, '');
      src = src.replace(/^import\s*\{([^}]*)\}\s*from\s*['"][^'"]+['"];?\s*$/mg, function (_, n) { return 'const {' + n + '} = __E;'; });
      src = src.replace(/^export\s+(function|const|let|class)\s+([A-Za-z_$][\w$]*)/mg, function (_, kw, n) { names.push(n); return kw + ' ' + n; });
      out += '(function(){\n' + src + '\nObject.assign(__E,{' + names.join(',') + '});\n})();\n';
    });
    out += 'return __E;';
    var code = Babel.transform(out, { presets: ['react'], parserOpts: { allowReturnOutsideFunction: true } }).code;
    return (new Function('React', code))(window.React);
  }
  window.rrReady = new Promise(function (resolve, reject) {
    function go() {
      var b = findBundle();
      if (b) return resolve(b);
      var s = document.createElement('script');
      s.src = root + '_ds_bundle.js';
      s.onload = function () { var b2 = findBundle(); if (b2) resolve(b2); else compileAll(); };
      s.onerror = compileAll;
      document.head.appendChild(s);
    }
    function compileAll() {
      Promise.all(FILES.map(function (f) { return fetch(root + 'components/' + f).then(function (r) { return r.text(); }); }))
        .then(function (t) { resolve(compile(t)); })['catch'](function (e) { console.error('[rr loader]', e); reject(e); });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();
  });
})();
