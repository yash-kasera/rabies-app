# Hospital portal UI kit (React + Tailwind)

Recreation for hospital staff at 1366×768 (works to 1024), desktop density.

Screens: Incoming reports (sorted by severity; Accept → Dialog → toast; empty state) · Vaccine doses (Day 0/3/7/28 chips carry a check icon + text; overdue shows icon + red text; row → SidePanel with date-time, selects, textarea, loading save).

Shares `../gov-portal/PortalShell.jsx` and sample data.
