function DoseTracker({ toast }) {
  const { DataTable, StatusBadge, SidePanel, Button, DateField, SelectField, TextArea, Icon } = window.RR;
  const days = [0, 3, 7, 28];
  const [rows, setRows] = React.useState([
    { id: 'RR-0141', name: 'Sunita Verma', done: 1, next: 'Tue 29 Sep', st: 'under_treatment' },
    { id: 'RR-0131', name: 'Vikas Tiwari', done: 4, next: '—', st: 'completed' },
    { id: 'RR-0119', name: 'Rahul Yadav', done: 2, next: 'Today', st: 'under_treatment' },
    { id: 'RR-0102', name: 'Kavita Dubey', done: 3, next: 'Overdue 2 days', st: 'under_treatment' },
  ]);
  const [sel, setSel] = React.useState(null);
  const [saving, setSaving] = React.useState(false);
  const Doses = ({ done }) => (
    <span style={{ display: 'inline-flex', gap: 4 }}>
      {days.map((d, i) => (
        <span key={d} title={'Day ' + d} style={{ display: 'inline-flex', alignItems: 'center', gap: 2, padding: '0 8px', minHeight: 24, borderRadius: 999, fontSize: 12, fontWeight: 600, border: '1px solid ' + (i < done ? 'var(--color-success-border)' : 'var(--color-border-strong)'), background: i < done ? 'var(--color-success-container)' : 'var(--color-surface)', color: i < done ? 'var(--color-on-success-container)' : 'var(--color-text-secondary)' }}>
          {i < done && <Icon name="check" size={12} />}D{d}
        </span>
      ))}
    </span>
  );
  const save = () => { setSaving(true); setTimeout(() => { setRows(rs => rs.map(r => r.id === sel.id ? { ...r, done: r.done + 1, st: r.done + 1 >= 4 ? 'completed' : r.st, next: r.done + 1 >= 4 ? '—' : 'Scheduled' } : r)); setSaving(false); toast('Dose recorded for ' + sel.name + '.'); setSel(null); }, 900); };
  return (
    <>
      <PageHead title="Vaccine doses" sub="Anti-rabies schedule: Day 0, 3, 7, 28" />
      <DataTable rows={rows} onRowClick={r => r.done < 4 && setSel(r)} selectedKey={sel && sel.id} columns={[
        { key: 'id', label: 'Report ID', render: r => <span className="rr-mono">{r.id}</span> },
        { key: 'name', label: 'Patient' },
        { key: 'done', label: 'Doses', render: r => <Doses done={r.done} /> },
        { key: 'next', label: 'Next dose', render: r => r.next.startsWith('Overdue') ? <span style={{ display: 'inline-flex', gap: 4, alignItems: 'center', color: 'var(--color-danger)', fontWeight: 600 }}><Icon name="triangle-alert" size={16} />{r.next}</span> : r.next },
        { key: 'st', label: 'Status', render: r => <StatusBadge kind="case" value={r.st} /> },
      ]} />
      {sel && (
        <SidePanel title={'Record dose — ' + sel.name} subtitle={'Dose ' + (sel.done + 1) + ' of 4 · Day ' + days[sel.done]} onClose={() => setSel(null)}
          footer={<><Button variant="secondary" onClick={() => setSel(null)}>Cancel</Button><Button icon="syringe" loading={saving} loadingLabel="Saving…" onClick={save}>Save dose</Button></>}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Doses done={sel.done} />
            <DateField label="Given on" mode="datetime" defaultValue="2026-09-28T11:05" />
            <SelectField label="Vaccine" options={[{ value: 'arv-id', label: 'ARV — intradermal (0.1 ml × 2 sites)' }, { value: 'arv-im', label: 'ARV — intramuscular (1 vial)' }]} />
            <SelectField label="Rabies immunoglobulin (RIG)" optional options={[{ value: 'no', label: 'Not given' }, { value: 'yes', label: 'Given' }]} />
            <TextArea label="Notes" optional rows={3} maxLength={200} />
          </div>
        </SidePanel>
      )}
    </>
  );
}
window.DoseTracker = DoseTracker;
