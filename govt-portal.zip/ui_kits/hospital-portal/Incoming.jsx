function IncomingQueue({ toast }) {
  const { Card, StatusBadge, Button, Dialog, EmptyState, Icon } = window.RR;
  const [items, setItems] = React.useState(window.GOV_CASES.filter(c => c.st === 'reported' || c.st === 'accepted').concat([{ id: 'RR-0143', name: 'Meena Kushwaha', age: 61, area: 'Madan Mahal, Ward 38', animal: 'Dog', sev: 'bleeding_wound', st: 'reported', t: 'Today 10:51' }]));
  const [accepting, setAccepting] = React.useState(null);
  const order = { multiple_bites: 0, deep_wound: 1, bleeding_wound: 2, minor_scratch: 3 };
  const list = items.filter(i => i.st === 'reported').sort((a, b) => order[a.sev] - order[b.sev]);
  const accept = c => { setItems(is => is.map(i => i.id === c.id ? { ...i, st: 'accepted' } : i)); setAccepting(null); toast('Accepted ' + c.id + '. The patient has been sent an SMS.'); };
  return (
    <>
      <PageHead title="Incoming bite reports" sub="Most urgent first · refreshes every 60 s" />
      {list.length === 0 ? <div className="rr-card"><EmptyState icon="circle-check" title="No reports waiting" body="New reports for your hospital will appear here." /></div> : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16 }}>
          {list.map(c => (
            <Card key={c.id}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, flexWrap: 'wrap' }}>
                  <StatusBadge kind="severity" value={c.sev} size="lg" />
                  <span style={{ display: 'flex', alignItems: 'center', gap: 4, color: 'var(--color-text-secondary)', fontSize: 13 }}><Icon name="clock" size={16} />{c.t}</span>
                </div>
                <div><div style={{ fontWeight: 600, fontSize: 16 }}>{c.name}, {c.age}</div><div style={{ color: 'var(--color-text-secondary)' }}>{c.animal} bite · {c.area}</div></div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  <Button icon="check" onClick={() => setAccepting(c)}>Accept patient</Button>
                  <Button variant="secondary" icon="phone">Call</Button>
                </div>
                <span className="rr-mono" style={{ color: 'var(--color-text-secondary)', fontSize: 12 }}>{c.id}</span>
              </div>
            </Card>
          ))}
        </div>
      )}
      {accepting && (
        <Dialog title="Accept this patient?" icon="hospital" onClose={() => setAccepting(null)}
          actions={<><Button variant="secondary" onClick={() => setAccepting(null)}>Not now</Button><Button onClick={() => accept(accepting)}>Accept patient</Button></>}>
          {accepting.name} will get an SMS with your hospital's address and be told to come today.
        </Dialog>
      )}
    </>
  );
}
window.IncomingQueue = IncomingQueue;
