function HomeScreen({ t, lang, go }) {
  const { Button, Card, List, ListItem, StatusBadge, Icon } = window.RR;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, padding: 16 }}>
      <Card padding="lg" style={{ background: 'var(--color-emergency-container)', borderColor: 'var(--color-emergency-container)' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <h1 style={{ margin: 0, fontSize: 'var(--text-title-lg-size)', lineHeight: 'var(--text-title-lg-lh)', fontWeight: 600, color: 'var(--color-on-emergency-container)' }}>{t.bitten}</h1>
          <p style={{ margin: 0, color: 'var(--color-on-emergency-container)' }}>{t.bittenSub}</p>
          <Button variant="emergency" size="lg" icon="siren" block onClick={() => go('report')}>{t.report}</Button>
          <Button variant="secondary" icon="phone" block>{t.call}</Button>
        </div>
      </Card>
      <Card variant="brand">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 44, height: 44, borderRadius: 999, background: 'var(--color-on-primary)', color: 'var(--color-primary)', flex: 'none' }}><Icon name="syringe" size={22} /></span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 14, lineHeight: '20px' }}>{t.nextDose} · {t.dayOf}</div>
            <div style={{ fontSize: 20, lineHeight: '28px', fontWeight: 600 }}>{lang === 'hi' ? 'शनिवार, 3 अक्टूबर' : 'Sat, 3 October'}</div>
            <div style={{ fontSize: 14, lineHeight: '20px' }}>Victoria District Hospital</div>
          </div>
        </div>
      </Card>
      <SectionTitle>{t.firstAid}</SectionTitle>
      <Card variant="tinted">
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
          <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 32, height: 32, borderRadius: 999, background: 'var(--color-primary)', color: 'var(--color-on-primary)', fontWeight: 600, flex: 'none' }}>1</span>
          <p style={{ margin: 0, fontSize: 'var(--text-body-lg-size)', lineHeight: 'var(--text-body-lg-lh)' }}>{t.wash}</p>
        </div>
        <div style={{ marginTop: 8 }}><Button variant="text" iconRight="chevron-right" onClick={() => go('learn')}>{t.seeAll}</Button></div>
      </Card>
      <SectionTitle>{t.notices}</SectionTitle>
      <List label={t.notices}>
        <ListItem icon="siren" title={lang === 'hi' ? 'गढ़ा में कुत्तों के काटने के मामले बढ़े' : 'More dog bites reported in Garha'} subtitle={<StatusBadge kind="notice" value="outbreak_alert" lang={lang} />} chevron onClick={() => {}} />
        <ListItem icon="hospital" title={lang === 'hi' ? 'रांझी सिविल अस्पताल में अब टीका उपलब्ध' : 'Vaccine now at Civil Hospital, Ranjhi'} subtitle={<StatusBadge kind="notice" value="new_hospital" lang={lang} />} chevron onClick={() => {}} />
      </List>
    </div>
  );
}
window.HomeScreen = HomeScreen;
