function AppBar({ t, title, onBack, lang, setLang }) {
  const { Icon, LogoSlot } = window.RR;
  return (
    <header style={{ display: 'flex', alignItems: 'center', gap: 8, minHeight: 56, padding: '4px 8px 4px ' + (onBack ? '4px' : '16px'), background: 'var(--color-surface)', borderBottom: '1px solid var(--color-border)' }}>
      {onBack ? <button className="rr-iconbtn" style={{ margin: 0 }} onClick={onBack} aria-label={t.back}><Icon name="arrow-left" size={24} /></button> : <LogoSlot size={32} />}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 'var(--text-title-sm-size)', lineHeight: 'var(--text-title-sm-lh)', fontWeight: 600 }}>{title || t.app}</div>
        {!title && <div style={{ fontSize: 13, lineHeight: '18px', color: 'var(--color-text-secondary)' }}>{t.city}</div>}
      </div>
      <button onClick={() => setLang(lang === 'en' ? 'hi' : 'en')} aria-label="Change language" style={{ minHeight: 40, minWidth: 48, padding: '0 12px', border: '1px solid var(--color-border-strong)', borderRadius: 999, background: 'var(--color-surface)', color: 'var(--color-primary)', font: 'inherit', fontWeight: 600, fontSize: 14, cursor: 'pointer' }}>{lang === 'en' ? 'हिंदी' : 'English'}</button>
    </header>
  );
}

function BottomNav({ t, tab, setTab }) {
  const { Icon } = window.RR;
  const items = [['home', 'house', t.home], ['hospitals', 'hospital', t.hospitals], ['reports', 'file-text', t.reports], ['learn', 'book-open', t.learn]];
  return (
    <nav style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0,1fr))', background: 'var(--color-surface)', borderTop: '1px solid var(--color-border)' }}>
      {items.map(([k, ic, label]) => {
        const on = tab === k;
        return (
          <button key={k} onClick={() => setTab(k)} aria-current={on ? 'page' : undefined} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2, minHeight: 64, padding: '8px 2px', border: 0, background: 'transparent', color: on ? 'var(--color-primary)' : 'var(--color-text-secondary)', font: 'inherit', fontSize: 12, lineHeight: '16px', fontWeight: on ? 600 : 400, cursor: 'pointer', textAlign: 'center' }}>
            <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 56, height: 28, borderRadius: 999, background: on ? 'var(--color-primary-container)' : 'transparent' }}><Icon name={ic} size={22} /></span>
            <span style={{ overflowWrap: 'anywhere' }}>{label}</span>
          </button>
        );
      })}
    </nav>
  );
}

function SectionTitle({ children, action }) {
  return <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 8, margin: '8px 0 0' }}><h2 style={{ margin: 0, fontSize: 'var(--text-title-sm-size)', lineHeight: 'var(--text-title-sm-lh)', fontWeight: 600 }}>{children}</h2>{action}</div>;
}
Object.assign(window, { AppBar, BottomNav, SectionTitle });
