# Citizen app UI kit (Flutter, Android-first)

HTML recreation of the citizen app used to review layout, copy and states before Flutter build. Frames: 360 px (376 incl. bezel) light and 320 px (336) dark.

Screens: Home (emergency card, next-dose card, first-aid preview, notices) · Report a bite (form with severity radio cards, validation, loading, success toast) · Hospitals (list-first, Map toggle loads on demand, skeleton) · My reports · First aid steps.

Toggle हिंदी in the app bar to check Devanagari wrapping; tick "offline" to see the banner.

Flutter mapping: AppBar → `AppBar`, BottomNav → `NavigationBar` (labels always shown), severity radio cards → `RadioListTile` in a bordered `Card`, Toast → `SnackBar` (floating). Theme: `tokens/flutter/rr_theme.dart`.
