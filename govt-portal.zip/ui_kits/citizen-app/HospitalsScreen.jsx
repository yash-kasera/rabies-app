function HospitalsScreen({ t, lang, offline }) {
  const { SegmentedToggle, List, ListItem, StatusBadge, Button, Skeleton, ErrorState } = window.RR;
  const [view, setView] = React.useState('list');
  const [loading, setLoading] = React.useState(true);
  React.useEffect(() => { const id = setTimeout(() => setLoading(false), 700); return () => clearTimeout(id); }, []);
  const H = [['Victoria District Hospital', 2.1, true, t.open24], ['Netaji Subhash Chandra Bose Medical College', 3.4, true, t.open24], ['Civil Hospital, Ranjhi', 4.8, false, '9 am – 5 pm'], ['Community Health Centre, Adhartal', 6.2, true, '8 am – 8 pm']];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: 16 }}>
      <SegmentedToggle label="View" value={view} onChange={setView} options={[{ value: 'list', label: t.list, icon: 'list' }, { value: 'map', label: t.map, icon: 'map' }]} />
      {view === 'map' ? (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, minHeight: 280, padding: 16, textAlign: 'center', borderRadius: 16, border: '1px dashed var(--color-border-strong)', background: 'repeating-linear-gradient(135deg, var(--color-surface-alt) 0 8px, var(--color-surface) 8px 16px)' }}>
          <span style={{ font: '12px/1.4 var(--font-mono)', color: 'var(--color-text-secondary)', background: 'var(--color-surface)', padding: '2px 6px' }}>map tiles — loaded on demand</span>
          <p style={{ margin: 0, background: 'var(--color-surface)', padding: '4px 8px', borderRadius: 8 }}>{t.mapNote}</p>
          <Button variant="secondary" icon="map">{t.loadMap}</Button>
        </div>
      ) : loading ? (
        <div className="rr-list" aria-busy="true"><Skeleton variant="list-item" /><Skeleton variant="list-item" /><Skeleton variant="list-item" /></div>
      ) : (
        <List label={t.hospitals}>
          {H.map(([n, d, a, hrs]) => <ListItem key={n} icon="hospital" title={n} subtitle={d + ' ' + t.km + ' · ' + hrs} meta={<StatusBadge kind="hospital" value={a ? 'active' : 'inactive'} lang={lang} />} chevron onClick={() => {}} />)}
        </List>
      )}
    </div>
  );
}

function LearnScreen({ t }) {
  const { Card } = window.RR;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: 16 }}>
      {t.steps.map((s, i) => (
        <Card key={i} variant={i === 2 ? 'default' : 'tinted'} style={i === 2 ? { borderColor: 'var(--color-danger-border)', background: 'var(--color-danger-container)' } : undefined}>
          <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
            <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 32, height: 32, borderRadius: 999, background: i === 2 ? 'var(--color-danger)' : 'var(--color-primary)', color: 'var(--color-on-primary)', fontWeight: 600, flex: 'none' }}>{i + 1}</span>
            <p style={{ margin: 0, fontSize: 'var(--text-body-lg-size)', lineHeight: 'var(--text-body-lg-lh)', color: i === 2 ? 'var(--color-on-danger-container)' : undefined }}>{s}</p>
          </div>
        </Card>
      ))}
    </div>
  );
}

function ReportsScreen({ t, lang }) {
  const { Card, StatusBadge, Button } = window.RR;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: 16 }}>
      {[['RR-0142', 'under_treatment', 'deep_wound', lang === 'hi' ? '28 सितंबर, 9:30' : '28 Sep, 9:30 am'], ['RR-0087', 'completed', 'minor_scratch', lang === 'hi' ? '2 अगस्त' : '2 Aug']].map(([id, st, sv, d]) => (
        <Card key={id} onClick={() => {}}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, flexWrap: 'wrap' }}><span className="rr-mono" style={{ fontWeight: 600 }}>{id}</span><span style={{ color: 'var(--color-text-secondary)', fontSize: 14 }}>{d}</span></div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}><StatusBadge kind="case" value={st} lang={lang} /><StatusBadge kind="severity" value={sv} lang={lang} /></div>
          </div>
        </Card>
      ))}
    </div>
  );
}
Object.assign(window, { HospitalsScreen, LearnScreen, ReportsScreen });
