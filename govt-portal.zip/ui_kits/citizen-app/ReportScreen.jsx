function ReportScreen({ t, lang, onSent }) {
  const { Button, SelectField, DateField, TextField, TextArea, StatusBadge, Icon } = window.RR;
  const [sev, setSev] = React.useState(null);
  const [animal, setAnimal] = React.useState('');
  const [phone, setPhone] = React.useState('');
  const [tried, setTried] = React.useState(false);
  const [sending, setSending] = React.useState(false);
  const send = () => {
    setTried(true);
    if (!sev || !animal || phone.replace(/\D/g, '').length !== 10) return;
    setSending(true);
    setTimeout(() => { setSending(false); onSent(); }, 1200);
  };
  const sevs = ['minor_scratch', 'bleeding_wound', 'deep_wound', 'multiple_bites'];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20, padding: 16 }}>
      <SelectField label={t.animal} placeholder={t.choose} value={animal} onChange={e => setAnimal(e.target.value)} error={tried && !animal ? t.required : undefined}
        options={[{ value: 'dog', label: t.dog }, { value: 'cat', label: t.cat }, { value: 'monkey', label: t.monkey }, { value: 'other', label: t.other }]} />
      <fieldset style={{ border: 0, margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: 8 }}>
        <legend className="rr-label" style={{ padding: 0, marginBottom: 6 }}>{t.wound}</legend>
        {sevs.map(s => {
          const on = sev === s;
          return (
            <label key={s} style={{ display: 'flex', alignItems: 'flex-start', gap: 12, minHeight: 56, padding: 12, borderRadius: 12, cursor: 'pointer', background: on ? 'var(--color-primary-container)' : 'var(--color-surface)', border: (on ? '2px solid var(--color-primary)' : '1px solid var(--color-border-strong)'), margin: on ? 0 : 1 }}>
              <input type="radio" name="sev" checked={on} onChange={() => setSev(s)} style={{ width: 20, height: 20, margin: '2px 0 0', accentColor: 'var(--color-primary)', flex: 'none' }} />
              <span style={{ display: 'flex', flexDirection: 'column', gap: 6, minWidth: 0 }}>
                <StatusBadge kind="severity" value={s} lang={lang} />
                <span style={{ color: 'var(--color-text-primary)' }}>{t.sev[s]}</span>
              </span>
            </label>
          );
        })}
        {tried && !sev && <div className="rr-errortext"><Icon name="circle-alert" size={16} />{t.required}</div>}
      </fieldset>
      <DateField label={t.when} mode="datetime" hint={t.whenHint} defaultValue="2026-09-28T09:30" />
      <TextArea label={t.where} hint={t.whereHint} rows={2} />
      <TextField label={t.name} autoComplete="name" />
      <TextField label={t.phone} icon="phone" type="tel" inputMode="numeric" value={phone} onChange={e => setPhone(e.target.value)} hint={t.phoneHint} error={tried && phone.replace(/\D/g, '').length !== 10 ? t.phoneErr : undefined} />
      <Button variant="emergency" size="lg" block icon="siren" loading={sending} loadingLabel={t.sending} onClick={send}>{t.send}</Button>
    </div>
  );
}
window.ReportScreen = ReportScreen;
