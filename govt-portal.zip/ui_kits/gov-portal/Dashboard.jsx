function GovDashboard({ go }) {
  const { StatTile, Card, DataTable, StatusBadge, List, ListItem, Button } = window.RR;
  const cases = window.GOV_CASES.slice(0, 4);
  return (
    <>
      <PageHead title="Jabalpur district overview" sub="Updated 2 minutes ago" actions={<Button variant="secondary" size="sm" icon="download">Download report</Button>} />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16, marginBottom: 24 }}>
        <StatTile label="New reports today" value="42" sub="12 more than yesterday" trend="up-bad" icon="file-text" onClick={() => go('cases')} />
        <StatTile label="Waiting for a hospital" value="7" sub="Oldest: 38 min" icon="clock" />
        <StatTile label="Doses given this week" value="1,284" sub="8% more than last week" trend="down-good" icon="syringe" />
        <StatTile label="Active hospitals" value="17 / 18" sub="1 out of vaccine stock" icon="hospital" onClick={() => go('hospitals')} />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 2fr) minmax(280px, 1fr)', gap: 16 }}>
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <h2 style={{ margin: 0, fontSize: 'var(--text-title-size)', fontWeight: 600 }}>Latest reports</h2>
            <Button variant="text" size="sm" iconRight="chevron-right" onClick={() => go('cases')}>All reports</Button>
          </div>
          <DataTable rows={cases} onRowClick={() => go('cases')} columns={[
            { key: 'id', label: 'Report ID', render: r => <span className="rr-mono">{r.id}</span> },
            { key: 'area', label: 'Area' },
            { key: 'sev', label: 'Severity', render: r => <StatusBadge kind="severity" value={r.sev} /> },
            { key: 'st', label: 'Status', render: r => <StatusBadge kind="case" value={r.st} /> },
          ]} />
        </div>
        <div>
          <h2 style={{ margin: '0 0 8px', fontSize: 'var(--text-title-size)', lineHeight: '40px', fontWeight: 600 }}>Notices</h2>
          <List label="Notices">
            <ListItem icon="siren" title="More dog bites in Garha (Ward 42)" subtitle={<StatusBadge kind="notice" value="outbreak_alert" />} chevron onClick={() => {}} />
            <ListItem icon="wrench" title="Portal down 11 pm – 1 am Sunday" subtitle={<StatusBadge kind="notice" value="maintenance_notice" />} chevron onClick={() => {}} />
            <ListItem icon="megaphone" title="World Rabies Day awareness drive" subtitle={<StatusBadge kind="notice" value="general_awareness" />} chevron onClick={() => {}} />
          </List>
        </div>
      </div>
    </>
  );
}
window.GovDashboard = GovDashboard;
