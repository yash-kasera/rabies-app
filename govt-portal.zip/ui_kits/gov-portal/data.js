window.GOV_CASES = [
  { id: 'RR-0142', name: 'Ramesh Patel', age: 34, area: 'Garha, Ward 42', animal: 'Dog', sev: 'deep_wound', st: 'reported', hosp: '—', t: 'Today 10:42' },
  { id: 'RR-0141', name: 'Sunita Verma', age: 27, area: 'Adhartal, Ward 11', animal: 'Dog', sev: 'minor_scratch', st: 'under_treatment', hosp: 'Victoria District Hospital', t: 'Today 09:15' },
  { id: 'RR-0139', name: 'Aarav Singh', age: 8, area: 'Garha, Ward 42', animal: 'Dog', sev: 'multiple_bites', st: 'accepted', hosp: 'NSCB Medical College', t: 'Today 08:03' },
  { id: 'RR-0137', name: 'Fatima Khan', age: 52, area: 'Ranjhi, Ward 67', animal: 'Monkey', sev: 'bleeding_wound', st: 'under_treatment', hosp: 'Civil Hospital, Ranjhi', t: 'Yesterday 18:20' },
  { id: 'RR-0131', name: 'Vikas Tiwari', age: 41, area: 'Napier Town, Ward 30', animal: 'Cat', sev: 'minor_scratch', st: 'completed', hosp: 'Victoria District Hospital', t: '24 Sep' },
  { id: 'RR-0128', name: 'Pooja Rajak', age: 19, area: 'Gorakhpur, Ward 23', animal: 'Dog', sev: 'bleeding_wound', st: 'cancelled', hosp: '—', t: '23 Sep' },
];
window.GOV_HOSPITALS = [
  { id: 'H01', name: 'Victoria District Hospital', area: 'Civil Lines', stock: 142, active: true, open: '24 hours' },
  { id: 'H02', name: 'NSCB Medical College', area: 'Garha', stock: 318, active: true, open: '24 hours' },
  { id: 'H03', name: 'Civil Hospital, Ranjhi', area: 'Ranjhi', stock: 0, active: false, open: '9 am – 5 pm' },
  { id: 'H04', name: 'CHC Adhartal', area: 'Adhartal', stock: 36, active: true, open: '8 am – 8 pm' },
];
