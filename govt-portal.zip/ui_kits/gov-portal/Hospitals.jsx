function GovHospitals({ toast }) {
  const { DataTable, StatusBadge, Button, Dialog } = window.RR;
  const [rows, setRows] = React.useState(window.GOV_HOSPITALS);
  const [confirm, setConfirm] = React.useState(null);
  const toggle = h => { setRows(rs => rs.map(r => r.id === h.id ? { ...r, active: !r.active } : r)); setConfirm(null); toast((h.active ? 'Marked inactive: ' : 'Marked active: ') + h.name); };
  return (
    <>
      <PageHead title="Hospitals" sub={rows.filter(r => r.active).length + ' of ' + rows.length + ' active'} actions={<Button size="sm" icon="plus">Add hospital</Button>} />
      <DataTable rows={rows} columns={[
        { key: 'name', label: 'Hospital', render: r => <b style={{ fontWeight: 600 }}>{r.name}</b> },
        { key: 'area', label: 'Area' },
        { key: 'open', label: 'Hours' },
        { key: 'stock', label: 'Vaccine vials', align: 'right', render: r => r.stock === 0 ? <span style={{ color: 'var(--color-danger)', fontWeight: 600 }}>0 — out of stock</span> : r.stock },
        { key: 'active', label: 'Status', render: r => <StatusBadge kind="hospital" value={r.active ? 'active' : 'inactive'} /> },
        { key: 'act', label: '', align: 'right', render: r => <Button variant={r.active ? 'text' : 'secondary'} size="sm" onClick={() => setConfirm(r)}>{r.active ? 'Mark inactive' : 'Mark active'}</Button> },
      ]} />
      {confirm && (
        <Dialog title={confirm.active ? 'Mark this hospital inactive?' : 'Mark this hospital active?'} icon={confirm.active ? 'triangle-alert' : 'hospital'} tone={confirm.active ? 'danger' : 'default'} onClose={() => setConfirm(null)}
          actions={<><Button variant="secondary" onClick={() => setConfirm(null)}>Cancel</Button><Button variant={confirm.active ? 'danger' : 'primary'} onClick={() => toggle(confirm)}>{confirm.active ? 'Mark inactive' : 'Mark active'}</Button></>}>
          {confirm.active ? confirm.name + ' will stop getting new bite reports. Citizens will not see it in the app.' : confirm.name + ' will start getting new bite reports.'}
        </Dialog>
      )}
    </>
  );
}
window.GovHospitals = GovHospitals;
