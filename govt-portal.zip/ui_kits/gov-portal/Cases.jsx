function GovCases() {
  const { DataTable, StatusBadge, SidePanel, Button, TextField, SelectField, DateField, EmptyState, ErrorState, SegmentedToggle } = window.RR;
  const [sel, setSel] = React.useState(null);
  const [st, setSt] = React.useState('');
  const [q, setQ] = React.useState('');
  const [view, setView] = React.useState('list');
  const [state, setState] = React.useState('ok');
  const rows = window.GOV_CASES.filter(r => (!st || r.st === st) && (!q || (r.id + r.name + r.area).toLowerCase().includes(q.toLowerCase())));
  return (
    <>
      <PageHead title="Bite reports" sub={rows.length + ' reports'} actions={<>
        <SegmentedToggle label="View" value={view} onChange={setView} options={[{ value: 'list', label: 'List', icon: 'list' }, { value: 'map', label: 'Map', icon: 'map' }]} />
        <Button variant="secondary" size="sm" onClick={() => setState(state === 'error' ? 'ok' : 'error')}>Demo: {state === 'error' ? 'data' : 'error'}</Button>
      </>} />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12, marginBottom: 16, alignItems: 'end' }}>
        <TextField label="Search" icon="search" placeholder="ID, name or area" value={q} onChange={e => setQ(e.target.value)} />
        <SelectField label="Status" placeholder="All statuses" value={st} onChange={e => setSt(e.target.value)} options={[
          { value: 'reported', label: 'Reported' }, { value: 'accepted', label: 'Accepted' }, { value: 'under_treatment', label: 'Under Treatment' }, { value: 'completed', label: 'Completed' }, { value: 'cancelled', label: 'Cancelled' }]} />
        <DateField label="From" mode="date" defaultValue="2026-09-21" />
        <DateField label="To" mode="date" defaultValue="2026-09-28" />
      </div>
      {state === 'error' ? <div className="rr-card"><ErrorState title="Could not load reports" body="The server did not answer. Your filters are kept." code="Error 504 · 10:42" onRetry={() => setState('ok')} /></div>
        : view === 'map' ? (
          <div style={{ minHeight: 360, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, border: '1px dashed var(--color-border-strong)', borderRadius: 16, background: 'repeating-linear-gradient(135deg, var(--color-surface-alt) 0 8px, var(--color-surface) 8px 16px)' }}>
            <span style={{ font: '12px var(--font-mono)', background: 'var(--color-surface)', padding: '2px 6px', color: 'var(--color-text-secondary)' }}>case map — loaded on demand</span>
            <Button variant="secondary" icon="map">Load map</Button>
          </div>
        ) : (
          <DataTable rows={rows} selectedKey={sel && sel.id} onRowClick={setSel}
            empty={<EmptyState icon="search" title="No reports match" body="Try another status or a wider date range." action={<Button variant="secondary" onClick={() => { setSt(''); setQ(''); }}>Clear filters</Button>} />}
            columns={[
              { key: 'id', label: 'Report ID', render: r => <span className="rr-mono">{r.id}</span> },
              { key: 'name', label: 'Patient' },
              { key: 'area', label: 'Area' },
              { key: 'sev', label: 'Severity', render: r => <StatusBadge kind="severity" value={r.sev} /> },
              { key: 'st', label: 'Status', render: r => <StatusBadge kind="case" value={r.st} /> },
              { key: 'hosp', label: 'Hospital' },
              { key: 't', label: 'Reported', align: 'right' },
            ]} />
        )}
      {sel && (
        <SidePanel title={'Report ' + sel.id} subtitle={'Reported ' + sel.t} onClose={() => setSel(null)}
          footer={<><Button variant="secondary" icon="phone">Call patient</Button><Button icon="hospital">Assign hospital</Button></>}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}><StatusBadge kind="severity" value={sel.sev} size="lg" /><StatusBadge kind="case" value={sel.st} size="lg" /></div>
            <Dl rows={[['Patient', sel.name + ', ' + sel.age], ['Animal', sel.animal], ['Area', sel.area], ['Hospital', sel.hosp], ['Mobile', '98260 •••• 21']]} />
          </div>
        </SidePanel>
      )}
    </>
  );
}
window.GovCases = GovCases;
