// Shared by the Government and Hospital portals. Sidebar 240px, header 56px, content max 1280px.
function PortalShell({ product, org, user, nav, page, setPage, offline, children }) {
  const { Icon, LogoSlot, OfflineBanner } = window.RR;
  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--color-background)', color: 'var(--color-text-primary)' }}>
      <aside style={{ width: 'var(--sidebar-w)', flex: 'none', display: 'flex', flexDirection: 'column', background: 'var(--color-surface)', borderRight: '1px solid var(--color-border)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 16px', minHeight: 64, borderBottom: '1px solid var(--color-border)' }}>
          <LogoSlot size={36} />
          <div style={{ minWidth: 0 }}>
            <div style={{ fontWeight: 600, fontSize: 15, lineHeight: '20px' }}>Rabies Response</div>
            <div style={{ fontSize: 12, lineHeight: '16px', color: 'var(--color-text-secondary)' }}>{product}</div>
          </div>
        </div>
        <nav style={{ display: 'flex', flexDirection: 'column', gap: 2, padding: 8 }}>
          {nav.map(([k, ic, label, count]) => {
            const on = page === k;
            return (
              <button key={k} onClick={() => setPage(k)} aria-current={on ? 'page' : undefined} style={{ display: 'flex', alignItems: 'center', gap: 10, minHeight: 40, padding: '8px 12px', border: 0, borderRadius: 999, background: on ? 'var(--color-primary-container)' : 'transparent', color: on ? 'var(--color-on-primary-container)' : 'var(--color-text-secondary)', font: 'inherit', fontSize: 14, fontWeight: on ? 600 : 400, textAlign: 'left', cursor: 'pointer' }}>
                <Icon name={ic} size={20} /><span style={{ flex: 1 }}>{label}</span>
                {count ? <span style={{ minWidth: 24, padding: '0 6px', borderRadius: 999, background: 'var(--color-emergency)', color: 'var(--color-on-emergency)', fontSize: 12, lineHeight: '20px', fontWeight: 600, textAlign: 'center' }}>{count}</span> : null}
              </button>
            );
          })}
        </nav>
        <div style={{ marginTop: 'auto', padding: 12, borderTop: '1px solid var(--color-border)', display: 'flex', alignItems: 'center', gap: 10, fontSize: 13 }}>
          <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 32, height: 32, borderRadius: 999, background: 'var(--color-surface-alt)' }}><Icon name="user" size={18} /></span>
          <div style={{ flex: 1, minWidth: 0 }}><div style={{ fontWeight: 600 }}>{user}</div><div style={{ color: 'var(--color-text-secondary)' }}>{org}</div></div>
          <button className="rr-iconbtn" style={{ margin: 0, width: 40, height: 40 }} aria-label="Sign out"><Icon name="log-out" size={18} /></button>
        </div>
      </aside>
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        {offline && <OfflineBanner lastSync="Last updated 10:42." onRetry={() => {}} />}
        <main style={{ flex: 1, padding: 24, maxWidth: 'var(--container-max)', width: '100%' }}>{children}</main>
      </div>
    </div>
  );
}

function PageHead({ title, sub, actions }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap', marginBottom: 20 }}>
      <div><h1 style={{ margin: 0, fontSize: 'var(--text-title-lg-size)', lineHeight: 'var(--text-title-lg-lh)', fontWeight: 600 }}>{title}</h1>
        {sub && <div style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--text-caption-size)' }}>{sub}</div>}</div>
      {actions && <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>{actions}</div>}
    </div>
  );
}

function Dl({ rows }) {
  return (
    <dl style={{ display: 'grid', gridTemplateColumns: '140px 1fr', gap: '8px 12px', margin: 0 }}>
      {rows.map(([k, v]) => <React.Fragment key={k}><dt style={{ color: 'var(--color-text-secondary)' }}>{k}</dt><dd style={{ margin: 0 }}>{v}</dd></React.Fragment>)}
    </dl>
  );
}
Object.assign(window, { PortalShell, PageHead, Dl });
