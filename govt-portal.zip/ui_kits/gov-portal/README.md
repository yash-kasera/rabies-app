# Government portal UI kit (React + Tailwind)

Recreation for health officials at 1366×768 (works to 1024). `data-density="desktop"` on `<html>` switches to 14 px body and 40 px controls.

Screens: Dashboard (4 KPI tiles, latest reports table, notices) · Bite reports (filters, List/Map toggle with map loaded on demand, table → SidePanel, empty + error states) · Hospitals (active/inactive with confirm Dialog + toast).

`PortalShell.jsx` (sidebar + header + offline slot) is shared with `ui_kits/hospital-portal`.
